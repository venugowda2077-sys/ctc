import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { AlertTriangle, Calculator, ChevronDown, ChevronRight, Sparkles, Loader2 } from 'lucide-react';
import {
  SAMPLE_OFFERS,
  formatINR,
  type CtcBreakupResult,
  type VariableImpactResult,
} from '../lib/ctcEngine';
import { AnimatedNumber } from './AnimatedNumber';

export interface DecodeOfferState {
  offerText: string;
  company: string;
  ctcLakhs: number;
  variablePercent: number;
  joiningBonus: number;
  noticePeriodDays: number;
  basicPercent: number;
  redFlags: string[];
  breakup: CtcBreakupResult;
  impact: VariableImpactResult;
}

interface DecodeOfferTabProps {
  state: DecodeOfferState;
  onChange: (updater: (prev: DecodeOfferState) => DecodeOfferState) => void;
  onRecalculate: () => void;
}

interface DebugPrompts {
  system: string;
  user: string;
}

export function DecodeOfferTab({ state, onChange, onRecalculate }: DecodeOfferTabProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const barsRef = useRef<HTMLDivElement>(null);

  const [selectedPreset, setSelectedPreset] = useState<string>(SAMPLE_OFFERS[0].id);
  const [extracting, setExtracting] = useState(false);
  const [extractError, setExtractError] = useState<string | null>(null);
  const [extractSuccess, setExtractSuccess] = useState(false);
  const [extractDebug, setExtractDebug] = useState<DebugPrompts | null>(null);
  const [showExtractDebug, setShowExtractDebug] = useState(false);

  const [explaining, setExplaining] = useState(false);
  const [explainError, setExplainError] = useState<string | null>(null);
  const [explanation, setExplanation] = useState<string>('');
  const [explainDebug, setExplainDebug] = useState<DebugPrompts | null>(null);
  const [showExplainDebug, setShowExplainDebug] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.decode-stagger', {
        y: 14,
        opacity: 0,
        duration: 0.45,
        stagger: 0.05,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
      });
    }, containerRef);
    return () => ctx.revert();
  }, []);

  // Animate breakdown bars whenever breakup changes
  useEffect(() => {
    if (!barsRef.current) return;
    const bars = barsRef.current.querySelectorAll('.bar-fill');
    gsap.fromTo(
      bars,
      { scaleX: 0 },
      { scaleX: 1, duration: 0.55, stagger: 0.04, ease: 'power3.out', transformOrigin: 'left center' },
    );
  }, [state.breakup, state.ctcLakhs, state.basicPercent]);

  const handlePresetChange = (presetId: string) => {
    setSelectedPreset(presetId);
    const found = SAMPLE_OFFERS.find((s) => s.id === presetId);
    if (found) {
      setExtractSuccess(false);
      setExtractError(null);
      setExplanation('');
      onChange((prev) => ({
        ...prev,
        offerText: found.text,
      }));
    }
  };

  const handleExtractOffer = async () => {
    if (!state.offerText.trim()) {
      setExtractError('Please paste an offer letter first.');
      return;
    }
    setExtracting(true);
    setExtractError(null);
    setExtractSuccess(false);

    try {
      const res = await fetch('/api/extract-offer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ offerText: state.offerText }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Could not extract offer details.');
      }

      const ext = data.extracted;
      onChange((prev) => ({
        ...prev,
        company: ext.company || 'Company',
        ctcLakhs: Number(ext.ctc_lakhs) || 0,
        variablePercent: Number(ext.variable_percent) || 0,
        joiningBonus: Number(ext.joining_bonus) || 0,
        noticePeriodDays: Number(ext.notice_period_days) || 0,
        redFlags: Array.isArray(ext.red_flags) ? ext.red_flags : [],
      }));
      setExtractDebug(data.debug || null);
      setExtractSuccess(true);
      setExplanation('');
      // Trigger recalculate on next tick via callback
      setTimeout(() => onRecalculate(), 0);
    } catch (err) {
      setExtractError(err instanceof Error ? err.message : 'Extraction failed.');
    } finally {
      setExtracting(false);
    }
  };

  const handleExplainPlainEnglish = async () => {
    setExplaining(true);
    setExplainError(null);

    try {
      const meta = {
        company: state.company,
        ctc_lakhs: state.ctcLakhs,
        variable_percent: state.variablePercent,
        joining_bonus: state.joiningBonus,
        notice_period_days: state.noticePeriodDays,
        basic_percent: state.basicPercent,
        red_flags: state.redFlags,
      };
      const res = await fetch('/api/explain-offer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          meta,
          breakup: state.breakup,
          impact: state.impact,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Could not generate explanation.');
      }
      setExplanation(data.explanation || '');
      setExplainDebug(data.debug || null);
    } catch (err) {
      setExplainError(err instanceof Error ? err.message : 'AI explanation failed.');
    } finally {
      setExplaining(false);
    }
  };

  const monthly = state.breakup.monthly;
  const totalMonthlyParts = monthly
    ? monthly.basic + monthly.hra + monthly.special_allowance + monthly.employer_pf + monthly.gratuity
    : 1;

  const breakdownRows = monthly
    ? [
        { label: 'Basic Salary', amount: monthly.basic, color: '#D4A853', tag: 'Taxable fixed' },
        { label: 'House Rent Allowance (HRA)', amount: monthly.hra, color: '#10B981', tag: '50% of basic' },
        { label: 'Special Allowance', amount: monthly.special_allowance, color: '#3B82F6', tag: 'Monthly gross' },
        { label: 'Employer PF', amount: monthly.employer_pf, color: '#F59E0B', tag: 'Locked EPF' },
        { label: 'Gratuity Accrual', amount: monthly.gratuity, color: '#94A3B8', tag: '5-yr vesting' },
      ]
    : [];

  return (
    <div ref={containerRef} className="space-y-6">
      {/* Offer Input Section */}
      <section className="decode-stagger bg-[#121722] border border-slate-800/90 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-base font-semibold text-slate-100">Offer Letter Input</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Load a Bengaluru fresher sample or paste your own offer letter text.
            </p>
          </div>
          <select
            aria-label="Load sample offer letter"
            value={selectedPreset}
            onChange={(e) => handlePresetChange(e.target.value)}
            className="bg-[#0B0E14] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-[#D4A853]"
          >
            {SAMPLE_OFFERS.map((sample) => (
              <option key={sample.id} value={sample.id}>
                {sample.label}
              </option>
            ))}
          </select>
        </div>

        <textarea
          rows={4}
          value={state.offerText}
          onChange={(e) => onChange((prev) => ({ ...prev, offerText: e.target.value }))}
          placeholder="Paste your job offer letter paragraph here..."
          className="w-full bg-[#0B0E14] border border-slate-800 rounded-lg p-3.5 text-sm text-slate-200 leading-relaxed focus:outline-none focus:border-[#D4A853] resize-y"
        />

        <div className="mt-3.5 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleExtractOffer}
            disabled={extracting}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#D4A853] text-[#0B0E14] text-xs font-semibold hover:bg-[#e1b866] disabled:opacity-60 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {extracting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            <span>{extracting ? 'Extracting Fields...' : 'Extract offer details'}</span>
          </button>

          {extractSuccess && (
            <span className="text-xs text-emerald-400 font-medium">
              Offer details extracted into the ledger below
            </span>
          )}
          {extractError && <span className="text-xs text-red-400">{extractError}</span>}
        </div>

        {extractDebug && (
          <div className="mt-3 pt-3 border-t border-slate-800/80">
            <button
              type="button"
              onClick={() => setShowExtractDebug((v) => !v)}
              className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
            >
              {showExtractDebug ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
              <span>See what we asked the AI</span>
            </button>
            {showExtractDebug && (
              <div className="mt-2.5 space-y-2 text-xs">
                <div className="text-slate-400">System Prompt:</div>
                <pre className="bg-[#0B0E14] border border-slate-800 rounded-lg p-3 text-slate-300 whitespace-pre-wrap font-mono text-[11px]">
                  {extractDebug.system}
                </pre>
                <div className="text-slate-400">User Prompt:</div>
                <pre className="bg-[#0B0E14] border border-slate-800 rounded-lg p-3 text-slate-300 whitespace-pre-wrap font-mono text-[11px]">
                  {extractDebug.user}
                </pre>
              </div>
            )}
          </div>
        )}
      </section>

      {/* Editable Extracted Parameters */}
      <section className="decode-stagger bg-[#121722] border border-slate-800/90 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
          <h2 className="text-base font-semibold text-slate-100">Extracted Details (Editable)</h2>
          <span className="text-xs text-slate-400">{state.company}</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
          <div>
            <label className="block text-[11px] text-slate-400 mb-1.5">CTC (Lakhs ₹)</label>
            <input
              type="number"
              min={0.5}
              max={200}
              step={0.5}
              value={state.ctcLakhs}
              onChange={(e) =>
                onChange((prev) => ({ ...prev, ctcLakhs: Math.max(0, Number(e.target.value)) }))
              }
              className="w-full bg-[#0B0E14] border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-slate-100 focus:outline-none focus:border-[#D4A853]"
            />
          </div>
          <div>
            <label className="block text-[11px] text-slate-400 mb-1.5">Variable Pay (%)</label>
            <input
              type="number"
              min={0}
              max={100}
              step={1}
              value={state.variablePercent}
              onChange={(e) =>
                onChange((prev) => ({
                  ...prev,
                  variablePercent: Math.min(100, Math.max(0, Number(e.target.value))),
                }))
              }
              className="w-full bg-[#0B0E14] border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-slate-100 focus:outline-none focus:border-[#D4A853]"
            />
          </div>
          <div>
            <label className="block text-[11px] text-slate-400 mb-1.5">Joining Bonus (₹)</label>
            <input
              type="number"
              min={0}
              step={5000}
              value={state.joiningBonus}
              onChange={(e) =>
                onChange((prev) => ({ ...prev, joiningBonus: Math.max(0, Number(e.target.value)) }))
              }
              className="w-full bg-[#0B0E14] border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-slate-100 focus:outline-none focus:border-[#D4A853]"
            />
          </div>
          <div>
            <label className="block text-[11px] text-slate-400 mb-1.5">Notice Period (Days)</label>
            <input
              type="number"
              min={0}
              max={365}
              step={5}
              value={state.noticePeriodDays}
              onChange={(e) =>
                onChange((prev) => ({ ...prev, noticePeriodDays: Math.max(0, Number(e.target.value)) }))
              }
              className="w-full bg-[#0B0E14] border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-slate-100 focus:outline-none focus:border-[#D4A853]"
            />
          </div>
        </div>

        {/* Basic % Slider + Calculate */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
          <div className="flex-1 min-w-[210px]">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="text-slate-300 font-medium">Basic salary share of CTC</span>
              <span className="font-mono tabular-nums text-[#D4A853] font-semibold">
                {state.basicPercent}%
              </span>
            </div>
            <input
              type="range"
              min={20}
              max={60}
              step={1}
              value={state.basicPercent}
              aria-label="Basic salary percentage of CTC"
              onChange={(e) =>
                onChange((prev) => ({ ...prev, basicPercent: Number(e.target.value) }))
              }
              className="vault-slider w-full"
            />
          </div>

          <button
            type="button"
            onClick={onRecalculate}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-100 text-slate-900 text-xs font-semibold hover:bg-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>Calculate</span>
          </button>
        </div>

        {/* Red Flags */}
        <div className="mt-5 pt-4 border-t border-slate-800/80">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-200 mb-2">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>Red Flags & Restrictive Clauses</span>
          </div>
          {state.redFlags.length > 0 ? (
            <ul className="space-y-2">
              {state.redFlags.map((flag, i) => (
                <li
                  key={`${flag}-${i}`}
                  className="bg-amber-950/35 border border-amber-800/60 rounded-lg px-3.5 py-2.5 text-xs text-amber-200 leading-relaxed"
                >
                  {flag}
                </li>
              ))}
            </ul>
          ) : (
            <div className="bg-emerald-950/25 border border-emerald-800/50 rounded-lg px-3.5 py-2.5 text-xs text-emerald-300">
              No restrictive bonds or clawback clauses detected in this offer.
            </div>
          )}
        </div>
      </section>

      {/* Deterministic Breakdown + Plain English AI Explanation */}
      <section className="decode-stagger grid grid-cols-1 xl:grid-cols-2 gap-5">
        {/* Salary Math Breakdown */}
        <div className="bg-[#121722] border border-slate-800/90 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-100">Salary Calculation</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Deterministic breakup synced directly with the 3D Salary Stack.
            </p>

            <div className="grid grid-cols-2 gap-3 mt-4">
              <div className="bg-[#0B0E14] border border-slate-800 rounded-lg p-3.5">
                <div className="text-[11px] text-slate-400">Approx Monthly (Pre-Tax)</div>
                <div className="text-xl font-semibold text-[#D4A853] mt-1">
                  <AnimatedNumber value={state.breakup.approx_monthly_before_income_tax || 0} />
                </div>
              </div>
              <div className="bg-[#0B0E14] border border-slate-800 rounded-lg p-3.5">
                <div className="text-[11px] text-slate-400">Guaranteed Monthly Pay</div>
                <div className="text-xl font-semibold text-emerald-400 mt-1">
                  <AnimatedNumber value={state.impact.guaranteed_monthly} />
                </div>
              </div>
            </div>

            {/* Proportional Breakdown Bars */}
            <div ref={barsRef} className="mt-5 space-y-3">
              {breakdownRows.map((row) => {
                const pct = Math.max(2, Math.round((row.amount / Math.max(totalMonthlyParts, 1)) * 100));
                return (
                  <div key={row.label}>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-slate-200 font-medium">
                        {row.label} <span className="text-slate-500 font-normal">· {row.tag}</span>
                      </span>
                      <span className="font-mono tabular-nums text-slate-100">
                        {formatINR(row.amount)}
                      </span>
                    </div>
                    <div className="h-2 bg-[#0B0E14] rounded-full overflow-hidden border border-slate-800/70">
                      <div
                        className="bar-fill h-full rounded-full"
                        style={{ width: `${pct}%`, backgroundColor: row.color }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <p className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400 leading-relaxed">
            {state.breakup.note}
          </p>
        </div>

        {/* AI Plain-English Explanation */}
        <div className="bg-[#121722] border border-slate-800/90 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-base font-semibold text-slate-100">AI Explanation</h3>
              <button
                type="button"
                onClick={handleExplainPlainEnglish}
                disabled={explaining}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0B0E14] border border-[#D4A853]/60 text-xs font-medium text-[#FDE68A] hover:bg-[#D4A853]/15 disabled:opacity-60 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                {explaining ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                <span>{explaining ? 'Writing...' : 'Explain in plain English'}</span>
              </button>
            </div>

            <div className="mt-4 bg-[#0B0E14] border border-slate-800 rounded-lg p-4 min-h-[175px]">
              {explanation ? (
                <p className="text-sm text-slate-200 leading-relaxed whitespace-pre-line">{explanation}</p>
              ) : (
                <p className="text-xs text-slate-400 leading-relaxed">
                  Click &ldquo;Explain in plain English&rdquo; to have CTC Anna translate your computed CTC, variable
                  pay gap, deductions, and red flags into 4 plain sentences plus one essential question to ask HR.
                </p>
              )}
              {explainError && <p className="text-xs text-red-400 mt-2">{explainError}</p>}
            </div>
          </div>

          {explainDebug && (
            <div className="mt-3 pt-3 border-t border-slate-800/80">
              <button
                type="button"
                onClick={() => setShowExplainDebug((v) => !v)}
                className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                {showExplainDebug ? (
                  <ChevronDown className="w-3.5 h-3.5" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5" />
                )}
                <span>See what we asked the AI</span>
              </button>
              {showExplainDebug && (
                <div className="mt-2 space-y-2 text-xs">
                  <pre className="bg-[#0B0E14] border border-slate-800 rounded-lg p-3 text-slate-300 whitespace-pre-wrap font-mono text-[11px]">
                    {explainDebug.system}
                  </pre>
                  <pre className="bg-[#0B0E14] border border-slate-800 rounded-lg p-3 text-slate-300 whitespace-pre-wrap font-mono text-[11px]">
                    {explainDebug.user}
                  </pre>
                </div>
              )}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
