import { useEffect, useRef } from 'react';
import gsap from 'gsap';

interface AnimatedNumberProps {
  value: number;
  prefix?: string;
  suffix?: string;
  className?: string;
}

export function AnimatedNumber({ value, prefix = '₹', suffix = '', className = '' }: AnimatedNumberProps) {
  const spanRef = useRef<HTMLSpanElement>(null);
  const proxyRef = useRef({ val: value });

  useEffect(() => {
    const el = spanRef.current;
    if (!el) return;

    const prefersReduced =
      typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (prefersReduced) {
      proxyRef.current.val = value;
      el.textContent = `${prefix}${Math.round(value).toLocaleString('en-IN')}${suffix}`;
      return;
    }

    const tween = gsap.to(proxyRef.current, {
      val: value,
      duration: 0.65,
      ease: 'power3.out',
      onUpdate: () => {
        if (spanRef.current) {
          spanRef.current.textContent = `${prefix}${Math.round(proxyRef.current.val).toLocaleString('en-IN')}${suffix}`;
        }
      },
    });

    return () => {
      tween.kill();
    };
  }, [value, prefix, suffix]);

  return (
    <span ref={spanRef} className={`tabular-nums ${className}`}>
      {prefix}
      {Math.round(value).toLocaleString('en-IN')}
      {suffix}
    </span>
  );
}
