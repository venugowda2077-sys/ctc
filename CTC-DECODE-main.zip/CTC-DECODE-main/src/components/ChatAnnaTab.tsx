import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { Send, Trash2, Cpu, ChevronDown, ChevronRight, Loader2 } from 'lucide-react';
import { TESTS, type AgentStep } from '../lib/ctcEngine';

export interface ChatTurn {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  steps?: AgentStep[];
}

interface ChatAnnaTabProps {
  messages: ChatTurn[];
  showAgentSteps: boolean;
  onToggleShowSteps: () => void;
  onSendMessage: (text: string) => Promise<void>;
  onClearChat: () => void;
  sending: boolean;
  error: string | null;
}

export function ChatAnnaTab({
  messages,
  showAgentSteps,
  onToggleShowSteps,
  onSendMessage,
  onClearChat,
  sending,
  error,
}: ChatAnnaTabProps) {
  const [input, setInput] = useState('');
  const [expandedSteps, setExpandedSteps] = useState<Record<string, boolean>>({});
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
      const last = listRef.current.querySelector('.chat-bubble:last-child');
      if (last) {
        gsap.fromTo(last, { y: 10, opacity: 0 }, { y: 0, opacity: 1, duration: 0.35, ease: 'power3.out' });
      }
    }
  }, [messages.length]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || sending) return;
    setInput('');
    await onSendMessage(trimmed);
  };

  const quickQuestions = [TESTS[0].question, TESTS[1].question, TESTS[2].question];

  return (
    <div className="bg-[#121722] border border-slate-800/90 rounded-xl p-5 flex flex-col h-[640px]">
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-base font-semibold text-slate-100">Chat with CTC Anna</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Tool-augmented salary advisor — deterministic formulas verify every figure and sync the 3D vault.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showAgentSteps}
              onChange={onToggleShowSteps}
              className="accent-[#D4A853] rounded"
            />
            <span>Show agent steps</span>
          </label>
          <button
            type="button"
            onClick={onClearChat}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#0B0E14] border border-slate-800 text-xs text-slate-300 hover:text-white hover:border-slate-700 transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear chat</span>
          </button>
        </div>
      </div>

      {/* Message Stream */}
      <div ref={listRef} className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center px-6">
            <p className="text-sm font-medium text-slate-200">
              Ask CTC Anna about salary breakups, variable pay, or competing offers
            </p>
            <p className="text-xs text-slate-400 mt-1.5 max-w-md leading-relaxed">
              When Anna invokes a calculator tool, the 3D Compensation Vault on the left updates automatically to show
              the exact numbers.
            </p>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.role === 'user';
            const hasSteps = Boolean(msg.steps && msg.steps.length > 0);
            const isOpen = expandedSteps[msg.id] ?? true;

            return (
              <div key={msg.id} className={`chat-bubble flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
                <div className="text-[11px] text-slate-500 mb-1 px-1">
                  {isUser ? 'You' : 'CTC Anna'}
                </div>
                <div
                  className={`max-w-[88%] rounded-xl px-4 py-3 text-sm leading-relaxed ${
                    isUser
                      ? 'bg-[#D4A853] text-[#0B0E14] font-medium'
                      : 'bg-[#0B0E14] border border-slate-800 text-slate-200'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                </div>

                {!isUser && showAgentSteps && hasSteps && (
                  <div className="mt-2 w-full max-w-[88%] bg-[#0E131D] border border-slate-800/90 rounded-lg px-3 py-2">
                    <button
                      type="button"
                      onClick={() =>
                        setExpandedSteps((prev) => ({ ...prev, [msg.id]: !isOpen }))
                      }
                      className="flex items-center gap-1.5 text-xs text-[#D4A853] hover:text-[#FDE68A] cursor-pointer"
                    >
                      {isOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                      <Cpu className="w-3.5 h-3.5" />
                      <span>See the agent steps ({msg.steps!.length})</span>
                    </button>

                    {isOpen && (
                      <div className="mt-2 space-y-2">
                        {msg.steps!.map((step, idx) => (
                          <div
                            key={`${msg.id}-step-${idx}`}
                            className="bg-[#0B0E14] border border-slate-800 rounded p-2.5 text-[11px] font-mono space-y-1"
                          >
                            <div className="text-sky-300">
                              AI picks: <span className="text-slate-100">{step.tool}({JSON.stringify(step.inputs)})</span>
                            </div>
                            <div className="text-emerald-300 break-all">
                              Calculator returns: <span className="text-slate-300">{JSON.stringify(step.result)}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}

        {sending && (
          <div className="flex items-center gap-2 text-xs text-slate-400 px-2">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-[#D4A853]" />
            <span>CTC Anna is running the ReAct tool loop...</span>
          </div>
        )}
      </div>

      {error && <p className="text-xs text-red-400 mb-2">{error}</p>}

      {/* Quick Example Prompts */}
      <div className="pt-3 border-t border-slate-800/80 space-y-3">
        <div className="flex flex-wrap gap-2">
          {quickQuestions.map((q) => (
            <button
              key={q}
              type="button"
              disabled={sending}
              onClick={() => onSendMessage(q)}
              className="text-left text-[11px] px-2.5 py-1.5 rounded-lg bg-[#0B0E14] border border-slate-800 text-slate-300 hover:border-[#D4A853]/60 hover:text-white transition-colors disabled:opacity-50 cursor-pointer"
            >
              {q}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask e.g. Break up a 6 lakh CTC with 40 percent basic"
            className="flex-1 bg-[#0B0E14] border border-slate-800 rounded-lg px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-[#D4A853]"
          />
          <button
            type="submit"
            disabled={sending || !input.trim()}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-[#D4A853] text-[#0B0E14] text-xs font-semibold hover:bg-[#e1b866] disabled:opacity-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send</span>
          </button>
        </form>
      </div>
    </div>
  );
}
