import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ArrowRight, PlayCircle } from 'lucide-react';
import { RULES, SYSTEM_EXPLAIN, SYSTEM_OFFER } from '../lib/ctcEngine';

const REACT_STAGES = [
  {
    step: '01. Think',
    summary: 'Inspect recent conversation and tool menu to select one tool or "none".',
    sample: 'Selected tool: compare_offers(ctc_a_lakhs=12, var_a=20, ctc_b=10, var_b=0)',
  },
  {
    step: '02. Act',
    summary: 'Execute deterministic TypeScript salary function with extracted numeric arguments.',
    sample: 'compare_offers(12, 20, 10, 0) -> executing...',
  },
  {
    step: '03. Observe',
    summary: 'Capture exact verified rupee figures and append them to the grounded fact trace.',
    sample: '{"offer_a_guaranteed": 960000, "offer_b_guaranteed": 1000000, "higher": "B", "difference": 40000}',
  },
  {
    step: '04. Repeat / Answer',
    summary: 'Either call another tool (up to 4 rounds) or write plain-English guidance from verified facts.',
    sample: 'Offer B gives ₹10,00,000 guaranteed vs ₹9,60,000 on Offer A — ₹40,000 higher.',
  },
];

export function HowItWorksTab() {
  const rootRef = useRef<HTMLDivElement>(null);
  const [activeStage, setActiveStage] = useState(0);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.arch-card', {
        y: 14,
        opacity: 0,
        duration: 0.45,
        stagger: 0.06,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  const handleAnimateCycle = () => {
    REACT_STAGES.forEach((_, idx) => {
      setTimeout(() => {
        setActiveStage(idx);
      }, idx * 650);
    });
  };

  return (
    <div ref={rootRef} className="space-y-6">
      {/* Interactive ReAct Loop Visualizer */}
      <section className="arch-card bg-[#121722] border border-slate-800/90 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-base font-semibold text-slate-100">The ReAct Agent Loop</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              A plain LLM guesses math. An agent pairs the LLM with deterministic tools in a 4-stage loop.
            </p>
          </div>
          <button
            type="button"
            onClick={handleAnimateCycle}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#D4A853] text-[#0B0E14] text-xs font-semibold hover:bg-[#e1b866] transition-colors cursor-pointer"
          >
            <PlayCircle className="w-3.5 h-3.5" />
            <span>Step Through Loop</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {REACT_STAGES.map((stage, idx) => {
            const isActive = activeStage === idx;
            return (
              <button
                key={stage.step}
                type="button"
                onClick={() => setActiveStage(idx)}
                className={`text-left rounded-xl p-4 border transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#0B0E14] border-[#D4A853] text-slate-100'
                    : 'bg-[#0B0E14]/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className={isActive ? 'text-[#D4A853]' : 'text-slate-300'}>{stage.step}</span>
                  {idx < 3 && <ArrowRight className="w-3.5 h-3.5 text-slate-600 hidden lg:block" />}
                </div>
                <p className="text-xs mt-2 leading-relaxed text-slate-300">{stage.summary}</p>
              </button>
            );
          })}
        </div>

        <div className="mt-3 bg-[#0B0E14] border border-slate-800 rounded-lg p-3.5">
          <div className="text-[11px] text-slate-400 mb-1">Trace Output · {REACT_STAGES[activeStage].step}</div>
          <code className="text-xs font-mono text-emerald-300 break-all">{REACT_STAGES[activeStage].sample}</code>
        </div>
      </section>

      {/* Structured Prompting & Tool Signatures */}
      <section className="arch-card bg-[#121722] border border-slate-800/90 rounded-xl p-5 space-y-4">
        <div>
          <h3 className="text-base font-semibold text-slate-100">Structured Prompting: Role, Task, Context, Format</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Every prompt constrains Gemini to rely strictly on literal offer text or computed rupee outputs.
          </p>
        </div>

        <div className="space-y-3">
          <div>
            <div className="text-xs font-medium text-slate-300 mb-1.5">Offer Extraction Prompt (SYSTEM_OFFER)</div>
            <pre className="bg-[#0B0E14] border border-slate-800 rounded-lg p-3.5 text-[11px] font-mono text-slate-300 whitespace-pre-wrap">
              {SYSTEM_OFFER}
            </pre>
          </div>

          <div>
            <div className="text-xs font-medium text-slate-300 mb-1.5">Plain-English Explanation Prompt (SYSTEM_EXPLAIN)</div>
            <pre className="bg-[#0B0E14] border border-slate-800 rounded-lg p-3.5 text-[11px] font-mono text-slate-300 whitespace-pre-wrap">
              {SYSTEM_EXPLAIN}
            </pre>
          </div>

          <div>
            <div className="text-xs font-medium text-slate-300 mb-1.5">CTC Anna Agent Rules (RULES)</div>
            <pre className="bg-[#0B0E14] border border-slate-800 rounded-lg p-3.5 text-[11px] font-mono text-slate-300 whitespace-pre-wrap">
              {RULES}
            </pre>
          </div>
        </div>
      </section>

      {/* Deterministic Tool Menu */}
      <section className="arch-card bg-[#121722] border border-slate-800/90 rounded-xl p-5 space-y-3">
        <h3 className="text-base font-semibold text-slate-100">Deterministic Salary Functions</h3>
        <pre className="bg-[#0B0E14] border border-slate-800 rounded-lg p-3.5 text-[11px] font-mono text-sky-300 whitespace-pre-wrap">
{`- ctcBreakup(ctc_lakhs: number, basic_percent: number) -> monthly basic, HRA, special allowance, employer PF, gratuity, approx monthly pre-tax
- variableImpact(ctc_lakhs: number, variable_percent: number) -> variable_yearly, guaranteed_yearly, guaranteed_monthly
- compareOffers(ctc_a_lakhs: number, variable_a_percent: number, ctc_b_lakhs: number, variable_b_percent: number) -> offer_a_guaranteed, offer_b_guaranteed, higher, difference`}
        </pre>
        <p className="text-xs text-slate-400">
          All names, companies, and sample numbers are fictional demo data. Always confirm real salary breakups and bond
          clauses with HR.
        </p>
      </section>
    </div>
  );
}
