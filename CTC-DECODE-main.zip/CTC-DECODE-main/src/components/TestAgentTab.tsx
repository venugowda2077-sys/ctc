import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { Play, CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { TESTS } from '../lib/ctcEngine';

interface TestRowResult {
  status: 'idle' | 'running' | 'passed' | 'failed';
  reason: string;
}

export function TestAgentTab() {
  const rootRef = useRef<HTMLDivElement>(null);
  const progressFillRef = useRef<HTMLDivElement>(null);

  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<TestRowResult[]>(
    TESTS.map(() => ({ status: 'idle', reason: 'Not run yet' })),
  );

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.test-stagger', {
        y: 12,
        opacity: 0,
        duration: 0.4,
        stagger: 0.05,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  useEffect(() => {
    if (!progressFillRef.current) return;
    gsap.to(progressFillRef.current, {
      scaleX: progress,
      duration: 0.35,
      ease: 'power2.out',
      transformOrigin: 'left center',
    });
  }, [progress]);

  const handleRunAll = async () => {
    setRunning(true);
    setProgress(0);
    setResults(TESTS.map(() => ({ status: 'idle', reason: 'Queued' })));

    for (let i = 0; i < TESTS.length; i++) {
      const tc = TESTS[i];
      setResults((prev) =>
        prev.map((r, idx) => (idx === i ? { status: 'running', reason: 'Running evaluation...' } : r)),
      );

      try {
        const res = await fetch('/api/run-test-case', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            question: tc.question,
            wantTools: tc.wantTools,
            wantInputs: tc.wantInputs,
          }),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Request failed');
        }
        setResults((prev) =>
          prev.map((r, idx) =>
            idx === i
              ? {
                  status: data.passed ? 'passed' : 'failed',
                  reason: data.reason || (data.passed ? 'Passed' : 'Failed'),
                }
              : r,
          ),
        );
      } catch (err) {
        setResults((prev) =>
          prev.map((r, idx) =>
            idx === i
              ? {
                  status: 'failed',
                  reason: err instanceof Error ? err.message : 'Network error',
                }
              : r,
          ),
        );
      }

      setProgress((i + 1) / TESTS.length);
    }

    setRunning(false);
  };

  const completedCount = results.filter((r) => r.status === 'passed' || r.status === 'failed').length;
  const passedCount = results.filter((r) => r.status === 'passed').length;

  return (
    <div ref={rootRef} className="space-y-5">
      <section className="test-stagger bg-[#121722] border border-slate-800/90 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-slate-100">Test the Agent</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Verify whether CTC Anna picks the exact deterministic tools and numeric inputs across all 8 test cases.
            </p>
          </div>

          <button
            type="button"
            onClick={handleRunAll}
            disabled={running}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#D4A853] text-[#0B0E14] text-xs font-semibold hover:bg-[#e1b866] disabled:opacity-60 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {running ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
            <span>{running ? 'Running Suite...' : 'Run all tests'}</span>
          </button>
        </div>

        {/* GSAP Progress Bar */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
            <span>Evaluation Progress</span>
            <span className="font-mono tabular-nums">
              {completedCount} / {TESTS.length}
              {completedCount === TESTS.length && ` · Score: ${passedCount} out of ${TESTS.length}`}
            </span>
          </div>
          <div className="h-2 bg-[#0B0E14] rounded-full overflow-hidden border border-slate-800">
            <div
              ref={progressFillRef}
              className="h-full bg-[#D4A853] rounded-full"
              style={{ transform: 'scaleX(0)' }}
            />
          </div>
        </div>
      </section>

      <section className="test-stagger bg-[#121722] border border-slate-800/90 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-[#0E131D] text-[11px] text-slate-400">
                <th className="py-3 px-4 font-medium">Status</th>
                <th className="py-3 px-4 font-medium">Question</th>
                <th className="py-3 px-4 font-medium">Expected Tools</th>
                <th className="py-3 px-4 font-medium">Expected Inputs</th>
                <th className="py-3 px-4 font-medium">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-xs">
              {TESTS.map((tc, idx) => {
                const row = results[idx];
                return (
                  <tr key={tc.question} className="hover:bg-[#0B0E14]/60 transition-colors">
                    <td className="py-3 px-4 whitespace-nowrap">
                      {row.status === 'passed' && (
                        <span className="inline-flex items-center gap-1.5 text-emerald-400 font-medium">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Pass</span>
                        </span>
                      )}
                      {row.status === 'failed' && (
                        <span className="inline-flex items-center gap-1.5 text-red-400 font-medium">
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Fail</span>
                        </span>
                      )}
                      {row.status === 'running' && (
                        <span className="inline-flex items-center gap-1.5 text-[#D4A853] font-medium">
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Running</span>
                        </span>
                      )}
                      {row.status === 'idle' && <span className="text-slate-500">Idle</span>}
                    </td>
                    <td className="py-3 px-4 text-slate-200 max-w-xs">{tc.question}</td>
                    <td className="py-3 px-4 font-mono text-[11px] text-sky-300 whitespace-nowrap">
                      {tc.wantTools.length > 0 ? tc.wantTools.join(', ') : 'none'}
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-400">
                      {Object.keys(tc.wantInputs).length > 0 ? JSON.stringify(tc.wantInputs) : 'none'}
                    </td>
                    <td className="py-3 px-4 text-slate-300">{row.reason}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
