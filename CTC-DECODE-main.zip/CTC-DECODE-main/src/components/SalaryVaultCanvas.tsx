import { useEffect, useRef, useState } from 'react';
import { ChevronDown, ChevronUp, Expand, Minimize2, RotateCw, Layers } from 'lucide-react';
import {
  SalaryVaultScene,
  type CameraPreset,
  type InspectedSegment,
  type VaultSceneData,
} from '../three/SalaryVaultScene';
import { AnimatedNumber } from './AnimatedNumber';

interface SalaryVaultCanvasProps {
  sceneData: VaultSceneData;
  isExpanded: boolean;
  onToggleExpand: () => void;
}

export function SalaryVaultCanvas({ sceneData, isExpanded, onToggleExpand }: SalaryVaultCanvasProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<SalaryVaultScene | null>(null);

  const [inspected, setInspected] = useState<InspectedSegment | null>(null);
  const [contextLost, setContextLost] = useState(false);
  const [exploded, setExploded] = useState(0.28);
  const [autoRotate, setAutoRotate] = useState(true);
  const [preset, setPreset] = useState<CameraPreset>('overview');
  const [dockCollapsed, setDockCollapsed] = useState(false);

  // Initialize Three.js scene once in isolated mountRef
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const instance = new SalaryVaultScene(container, sceneData, {
      onInspect: (seg) => setInspected(seg),
      onContextLost: (lost) => setContextLost(lost),
    });
    sceneRef.current = instance;

    return () => {
      instance.dispose();
      sceneRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Push live data updates without tearing down WebGL context
  useEffect(() => {
    if (sceneRef.current) {
      sceneRef.current.updateData(sceneData);
      setPreset(sceneData.mode === 'compare' ? 'compare' : 'overview');
    }
  }, [sceneData]);

  // Resize observer so layout expansion smoothly resizes canvas
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;
    const ro = new ResizeObserver(() => {
      window.dispatchEvent(new Event('resize'));
    });
    ro.observe(container);
    return () => ro.disconnect();
  }, []);

  const handleExplodeChange = (val: number) => {
    setExploded(val);
    sceneRef.current?.setExploded(val);
  };

  const handlePresetClick = (nextPreset: CameraPreset) => {
    setPreset(nextPreset);
    sceneRef.current?.setCameraPreset(nextPreset);
  };

  const handleAutoRotateToggle = () => {
    const next = !autoRotate;
    setAutoRotate(next);
    sceneRef.current?.setAutoRotate(next);
  };

  return (
    <div className="relative w-full h-full min-h-[420px] bg-[#0B0E14] rounded-xl border border-slate-800/80 overflow-hidden select-none">
      {/* Isolated WebGL mount container */}
      <div ref={mountRef} className="w-full h-full" />

      {/* Context lost graceful fallback */}
      {contextLost && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#0B0E14] text-slate-300 p-6 text-center z-20">
          <p className="text-sm font-medium text-slate-200">3D Graphics Context Suspended</p>
          <p className="text-xs text-slate-400 mt-1">
            All salary calculations remain live in the ledger workspace.
          </p>
        </div>
      )}

      {/* Minimal Top-Left Spec Badge (solid rgba surface, no backdrop-blur over WebGL) */}
      <div className="absolute top-4 left-4 right-4 flex items-start justify-between pointer-events-none z-10">
        <div className="bg-[#0B0E14]/90 border border-slate-800 rounded-lg px-3.5 py-2.5 pointer-events-auto">
          <div className="text-[11px] text-slate-400 tracking-wide">
            {sceneData.mode === 'compare' ? 'Offer Comparison Vault' : `${sceneData.company} · 3D Salary Stack`}
          </div>
          <div className="mt-0.5 flex items-baseline gap-2.5">
            {sceneData.mode === 'compare' ? (
              <span className="text-base font-semibold text-slate-100 tabular-nums">
                {sceneData.compare.higher === 'same'
                  ? 'Equal Guaranteed Pay'
                  : `Offer ${sceneData.compare.higher} Leads by `}
                {sceneData.compare.higher !== 'same' && (
                  <AnimatedNumber value={sceneData.compare.difference} className="text-[#D4A853]" />
                )}
              </span>
            ) : (
              <>
                <AnimatedNumber
                  value={sceneData.approxMonthlyBeforeTax}
                  suffix="/mo"
                  className="text-lg font-semibold text-[#D4A853]"
                />
                <span className="text-xs text-slate-400">before income tax</span>
              </>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={onToggleExpand}
          aria-label={isExpanded ? 'Collapse 3D stage' : 'Expand 3D stage'}
          className="pointer-events-auto flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#0B0E14]/90 border border-slate-800 text-xs font-medium text-slate-200 hover:border-[#D4A853]/60 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Expand className="w-3.5 h-3.5" />}
          <span>{isExpanded ? 'Split View' : 'Full Stage'}</span>
        </button>
      </div>

      {/* Interactive Raycaster Inspection Callout (only appears on hover/click of 3D segment) */}
      {inspected && (
        <div className="absolute top-24 left-4 max-w-[270px] bg-[#0F141F]/95 border border-slate-700/90 rounded-lg p-3.5 z-10 pointer-events-none transition-opacity duration-150">
          <div className="flex items-center justify-between gap-2 text-[11px] text-slate-400">
            <span>{inspected.category}</span>
            <span
              className="w-2.5 h-2.5 rounded-sm shrink-0"
              style={{ backgroundColor: inspected.accentHex }}
            />
          </div>
          <div className="mt-1 text-sm font-semibold text-slate-100">{inspected.label}</div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-base font-semibold font-mono tabular-nums" style={{ color: inspected.accentHex }}>
              {inspected.primaryValue}
            </span>
          </div>
          <div className="text-xs text-slate-300 mt-0.5">{inspected.secondaryValue}</div>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">{inspected.description}</p>
        </div>
      )}

      {/* Collapsible Bottom Control Dock (Zero Viewport Occlusion) */}
      <div
        className={`absolute bottom-4 left-1/2 -translate-x-1/2 w-[min(640px,94%)] z-10 transition-transform duration-200 ${
          dockCollapsed ? 'translate-y-[calc(100%-34px)]' : 'translate-y-0'
        }`}
      >
        <div className="flex justify-center">
          <button
            type="button"
            onClick={() => setDockCollapsed((v) => !v)}
            className="flex items-center gap-1.5 px-3 py-1 rounded-t-lg bg-[#121722]/95 border border-b-0 border-slate-800 text-[11px] font-medium text-slate-300 hover:text-white cursor-pointer"
          >
            {dockCollapsed ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            <span>{dockCollapsed ? 'Show Controls' : 'Hide Controls'}</span>
          </button>
        </div>

        <div className="bg-[#121722]/95 border border-slate-800 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          {/* Exploded Stack Slider */}
          <div className="flex items-center gap-2.5 min-w-[165px]">
            <Layers className="w-3.5 h-3.5 text-[#D4A853] shrink-0" />
            <span className="text-xs text-slate-300 whitespace-nowrap">Explode</span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={exploded}
              aria-label="Explode 3D salary layers"
              onChange={(e) => handleExplodeChange(Number(e.target.value))}
              className="vault-slider w-24"
            />
          </div>

          {/* Camera Presets */}
          <div className="flex items-center gap-1 bg-[#0B0E14] p-1 rounded-lg border border-slate-800/80">
            {(
              [
                { id: 'overview', label: 'Overview' },
                { id: 'core', label: 'In-Hand' },
                { id: 'deductions', label: 'At-Risk' },
                { id: 'compare', label: 'Towers' },
              ] as const
            ).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => handlePresetClick(item.id)}
                className={`px-2.5 py-1 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  preset === item.id
                    ? 'bg-[#D4A853] text-[#0B0E14]'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Auto-Orbit Toggle */}
          <button
            type="button"
            onClick={handleAutoRotateToggle}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              autoRotate
                ? 'border-[#D4A853]/50 bg-[#D4A853]/10 text-[#FDE68A]'
                : 'border-slate-800 bg-[#0B0E14] text-slate-400 hover:text-slate-200'
            }`}
          >
            <RotateCw className="w-3 h-3" />
            <span>Orbit</span>
          </button>
        </div>
      </div>
    </div>
  );
}
