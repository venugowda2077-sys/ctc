import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { Scale, Trophy } from 'lucide-react';
import { formatINR, type OfferComparisonResult } from '../lib/ctcEngine';
import { AnimatedNumber } from './AnimatedNumber';

export interface CompareOffersState {
  ctcA: number;
  varA: number;
  ctcB: number;
  varB: number;
  result: OfferComparisonResult;
}

interface CompareOffersTabProps {
  state: CompareOffersState;
  onChange: (updater: (prev: CompareOffersState) => CompareOffersState) => void;
  onCompare: () => void;
}

export function CompareOffersTab({ state, onChange, onCompare }: CompareOffersTabProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const barsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.cmp-stagger', {
        y: 14,
        opacity: 0,
        duration: 0.45,
        stagger: 0.06,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  useEffect(() => {
    if (!barsRef.current) return;
    const fills = barsRef.current.querySelectorAll('.cmp-bar-fill');
    gsap.fromTo(
      fills,
      { scaleX: 0 },
      { scaleX: 1, duration: 0.55, stagger: 0.08, ease: 'power3.out', transformOrigin: 'left center' },
    );
  }, [state.result]);

  const { result } = state;
  const maxGuaranteed = Math.max(result.offer_a_guaranteed, result.offer_b_guaranteed, 1);
  const pctA = Math.round((result.offer_a_guaranteed / maxGuaranteed) * 100);
  const pctB = Math.round((result.offer_b_guaranteed / maxGuaranteed) * 100);

  return (
    <div ref={rootRef} className="space-y-6">
      <section className="cmp-stagger bg-[#121722] border border-slate-800/90 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
          <div>
            <h2 className="text-base font-semibold text-slate-100">Compare Two Job Offers</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Compare guaranteed yearly pay (CTC minus variable pay) to avoid headline CTC traps.
            </p>
          </div>
          <button
            type="button"
            onClick={onCompare}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#D4A853] text-[#0B0E14] text-xs font-semibold hover:bg-[#e1b866] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Scale className="w-3.5 h-3.5" />
            <span>Compare Offers</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Offer A */}
          <div className="bg-[#0B0E14] border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-[#D4A853]">Offer A</span>
              <span className="text-xs font-mono tabular-nums text-slate-400">
                {100 - state.varA}% fixed
              </span>
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Offer A CTC (Lakhs ₹)</label>
              <input
                type="number"
                min={0}
                max={200}
                step={0.5}
                value={state.ctcA}
                onChange={(e) =>
                  onChange((prev) => ({ ...prev, ctcA: Math.max(0, Number(e.target.value)) }))
                }
                className="w-full bg-[#121722] border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-slate-100 focus:outline-none focus:border-[#D4A853]"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Offer A Variable Pay (%)</label>
              <input
                type="number"
                min={0}
                max={100}
                step={1}
                value={state.varA}
                onChange={(e) =>
                  onChange((prev) => ({
                    ...prev,
                    varA: Math.min(100, Math.max(0, Number(e.target.value))),
                  }))
                }
                className="w-full bg-[#121722] border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-slate-100 focus:outline-none focus:border-[#D4A853]"
              />
            </div>
          </div>

          {/* Offer B */}
          <div className="bg-[#0B0E14] border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-emerald-400">Offer B</span>
              <span className="text-xs font-mono tabular-nums text-slate-400">
                {100 - state.varB}% fixed
              </span>
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Offer B CTC (Lakhs ₹)</label>
              <input
                type="number"
                min={0}
                max={200}
                step={0.5}
                value={state.ctcB}
                onChange={(e) =>
                  onChange((prev) => ({ ...prev, ctcB: Math.max(0, Number(e.target.value)) }))
                }
                className="w-full bg-[#121722] border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-slate-100 focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Offer B Variable Pay (%)</label>
              <input
                type="number"
                min={0}
                max={100}
                step={1}
                value={state.varB}
                onChange={(e) =>
                  onChange((prev) => ({
                    ...prev,
                    varB: Math.min(100, Math.max(0, Number(e.target.value))),
                  }))
                }
                className="w-full bg-[#121722] border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-slate-100 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Winner Summary & Proportional Bars */}
      <section className="cmp-stagger bg-[#121722] border border-slate-800/90 rounded-xl p-5 space-y-5">
        <div className="flex items-start gap-3 bg-[#0B0E14] border border-slate-800 rounded-xl p-4">
          <Trophy
            className={`w-5 h-5 shrink-0 mt-0.5 ${
              result.higher === 'same' ? 'text-sky-400' : 'text-[#D4A853]'
            }`}
          />
          <div>
            {result.higher === 'same' ? (
              <p className="text-sm font-semibold text-slate-100">
                Both offers provide identical guaranteed yearly pay of{' '}
                <AnimatedNumber value={result.offer_a_guaranteed} className="text-sky-400" />
              </p>
            ) : (
              <p className="text-sm font-semibold text-slate-100">
                Offer {result.higher} is higher in guaranteed yearly pay by{' '}
                <AnimatedNumber value={result.difference} className="text-[#D4A853]" />
              </p>
            )}
            <p className="text-xs text-slate-400 mt-1 tabular-nums font-mono">
              Offer A: {formatINR(result.offer_a_guaranteed)}/yr vs Offer B: {formatINR(result.offer_b_guaranteed)}/yr
            </p>
          </div>
        </div>

        <div ref={barsRef} className="space-y-4">
          <div>
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="font-medium text-slate-200">
                Offer A Guaranteed Yearly Pay ({state.ctcA} LPA · {state.varA}% variable)
              </span>
              <AnimatedNumber value={result.offer_a_guaranteed} className="text-sm font-semibold text-[#D4A853]" />
            </div>
            <div className="h-3.5 bg-[#0B0E14] rounded-lg overflow-hidden border border-slate-800">
              <div
                className="cmp-bar-fill h-full bg-[#D4A853] rounded-lg"
                style={{ width: `${pctA}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="font-medium text-slate-200">
                Offer B Guaranteed Yearly Pay ({state.ctcB} LPA · {state.varB}% variable)
              </span>
              <AnimatedNumber value={result.offer_b_guaranteed} className="text-sm font-semibold text-emerald-400" />
            </div>
            <div className="h-3.5 bg-[#0B0E14] rounded-lg overflow-hidden border border-slate-800">
              <div
                className="cmp-bar-fill h-full bg-emerald-500 rounded-lg"
                style={{ width: `${pctB}%` }}
              />
            </div>
          </div>
        </div>

        {/* Quick Classic Trap Preset */}
        <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
          <span>Try the classic fresher trap: 12 LPA (20% variable) vs 10 LPA fixed</span>
          <button
            type="button"
            onClick={() => {
              onChange((prev) => ({ ...prev, ctcA: 12, varA: 20, ctcB: 10, varB: 0 }));
              setTimeout(() => onCompare(), 0);
            }}
            className="px-3 py-1.5 rounded-lg bg-[#0B0E14] border border-slate-700 text-slate-200 hover:border-[#D4A853] transition-colors cursor-pointer"
          >
            Load 12 vs 10 LPA Example
          </button>
        </div>
      </section>
    </div>
  );
}
