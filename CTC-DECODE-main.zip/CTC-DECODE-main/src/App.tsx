import { useEffect, useMemo, useRef, useState } from 'react';
import gsap from 'gsap';
import {
  SAMPLE_OFFERS,
  compareOffers,
  ctcBreakup,
  variableImpact,
} from './lib/ctcEngine';
import { SalaryVaultCanvas } from './components/SalaryVaultCanvas';
import { DecodeOfferTab, type DecodeOfferState } from './components/DecodeOfferTab';
import { CompareOffersTab, type CompareOffersState } from './components/CompareOffersTab';
import { ChatAnnaTab, type ChatTurn } from './components/ChatAnnaTab';
import { TestAgentTab } from './components/TestAgentTab';
import { HowItWorksTab } from './components/HowItWorksTab';
import type { VaultSceneData } from './three/SalaryVaultScene';

type ActiveTab = 'decode' | 'compare' | 'chat' | 'test' | 'how';

const TABS: Array<{ id: ActiveTab; label: string }> = [
  { id: 'decode', label: 'Decode Offer' },
  { id: 'compare', label: 'Compare' },
  { id: 'chat', label: 'CTC Anna' },
  { id: 'test', label: 'Test Agent' },
  { id: 'how', label: 'How It Works' },
];

export default function App() {
  const headerRef = useRef<HTMLElement>(null);

  const [activeTab, setActiveTab] = useState<ActiveTab>('decode');
  const [stageExpanded, setStageExpanded] = useState(false);

  // Decode tab state (initialized with Example 1: Indira Infotech)
  const [decodeState, setDecodeState] = useState<DecodeOfferState>(() => ({
    offerText: SAMPLE_OFFERS[0].text,
    company: 'Indira Infotech',
    ctcLakhs: 6.5,
    variablePercent: 10,
    joiningBonus: 25000,
    noticePeriodDays: 60,
    basicPercent: 40,
    redFlags: ['A service agreement of 2 years applies; leaving earlier means a penalty of Rs 1 lakh.'],
    breakup: ctcBreakup(6.5, 40),
    impact: variableImpact(6.5, 10),
  }));

  // Compare tab state
  const [compareState, setCompareState] = useState<CompareOffersState>(() => ({
    ctcA: 6.5,
    varA: 10,
    ctcB: 6.0,
    varB: 0,
    result: compareOffers(6.5, 10, 6.0, 0),
  }));

  // Chat tab state
  const [chatMessages, setChatMessages] = useState<ChatTurn[]>([]);
  const [showAgentSteps, setShowAgentSteps] = useState(true);
  const [sendingChat, setSendingChat] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);

  // GSAP initial entrance choreography
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.hero-entrance', {
        y: 12,
        opacity: 0,
        duration: 0.5,
        stagger: 0.06,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
      });
    }, headerRef);
    return () => ctx.revert();
  }, []);

  // Keep Decode math live as user drags Basic % slider or adjusts inputs
  const handleRecalculateDecode = () => {
    setDecodeState((prev) => ({
      ...prev,
      breakup: ctcBreakup(prev.ctcLakhs, prev.basicPercent),
      impact: variableImpact(prev.ctcLakhs, prev.variablePercent),
    }));
  };

  useEffect(() => {
    setDecodeState((prev) => ({
      ...prev,
      breakup: ctcBreakup(prev.ctcLakhs, prev.basicPercent),
      impact: variableImpact(prev.ctcLakhs, prev.variablePercent),
    }));
  }, [decodeState.ctcLakhs, decodeState.basicPercent, decodeState.variablePercent]);

  const handleCompare = () => {
    setCompareState((prev) => ({
      ...prev,
      result: compareOffers(prev.ctcA, prev.varA, prev.ctcB, prev.varB),
    }));
  };

  useEffect(() => {
    setCompareState((prev) => ({
      ...prev,
      result: compareOffers(prev.ctcA, prev.varA, prev.ctcB, prev.varB),
    }));
  }, [compareState.ctcA, compareState.varA, compareState.ctcB, compareState.varB]);

  const handleSendChat = async (text: string) => {
    const userTurn: ChatTurn = {
      id: `u-${Date.now()}`,
      role: 'user',
      content: text,
    };
    const nextHistory = [...chatMessages, userTurn];
    setChatMessages(nextHistory);
    setSendingChat(true);
    setChatError(null);

    try {
      const res = await fetch('/api/agent-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: chatMessages.map((m) => ({ role: m.role, content: m.content })),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'CTC Anna could not answer.');
      }

      const assistantTurn: ChatTurn = {
        id: `a-${Date.now()}`,
        role: 'assistant',
        content: data.answer || '',
        steps: data.steps || [],
      };
      setChatMessages([...nextHistory, assistantTurn]);

      // Synchronize the 3D Compensation Vault with whatever tool CTC Anna ran
      const steps = Array.isArray(data.steps) ? data.steps : [];
      for (const step of steps) {
        if (step.tool === 'ctc_breakup' && step.inputs) {
          const ctc = Number(step.inputs.ctc_lakhs) || decodeState.ctcLakhs;
          const basic = Number(step.inputs.basic_percent) || decodeState.basicPercent;
          setDecodeState((prev) => ({
            ...prev,
            company: 'CTC Anna Query',
            ctcLakhs: ctc,
            basicPercent: basic,
            variablePercent: 0,
            redFlags: [],
            breakup: ctcBreakup(ctc, basic),
            impact: variableImpact(ctc, 0),
          }));
        } else if (step.tool === 'variable_impact' && step.inputs) {
          const ctc = Number(step.inputs.ctc_lakhs) || decodeState.ctcLakhs;
          const varPct = Number(step.inputs.variable_percent) || 0;
          setDecodeState((prev) => ({
            ...prev,
            company: 'CTC Anna Query',
            ctcLakhs: ctc,
            variablePercent: varPct,
            redFlags: [],
            breakup: ctcBreakup(ctc, prev.basicPercent),
            impact: variableImpact(ctc, varPct),
          }));
        } else if (step.tool === 'compare_offers' && step.inputs) {
          const ctcA = Number(step.inputs.ctc_a_lakhs) || 6.5;
          const varA = Number(step.inputs.variable_a_percent) || 0;
          const ctcB = Number(step.inputs.ctc_b_lakhs) || 6;
          const varB = Number(step.inputs.variable_b_percent) || 0;
          setCompareState({
            ctcA,
            varA,
            ctcB,
            varB,
            result: compareOffers(ctcA, varA, ctcB, varB),
          });
        }
      }
    } catch (err) {
      setChatError(err instanceof Error ? err.message : 'Chat failed.');
    } finally {
      setSendingChat(false);
    }
  };

  // Compute live Three.js Vault scene payload
  const vaultData: VaultSceneData = useMemo(() => {
    const monthly = decodeState.breakup.monthly || {
      basic: 0,
      hra: 0,
      special_allowance: 0,
      employer_pf: 0,
      gratuity: 0,
    };

    return {
      mode: activeTab === 'compare' ? 'compare' : 'decode',
      company: decodeState.company,
      ctcLakhs: decodeState.ctcLakhs,
      basicPercent: decodeState.basicPercent,
      variablePercent: decodeState.variablePercent,
      monthly,
      approxMonthlyBeforeTax: decodeState.breakup.approx_monthly_before_income_tax || 0,
      guaranteedMonthly: decodeState.impact.guaranteed_monthly,
      redFlags: decodeState.redFlags,
      compare: {
        ctcA: compareState.ctcA,
        varA: compareState.varA,
        ctcB: compareState.ctcB,
        varB: compareState.varB,
        guaranteedA: compareState.result.offer_a_guaranteed,
        guaranteedB: compareState.result.offer_b_guaranteed,
        higher: compareState.result.higher,
        difference: compareState.result.difference,
      },
    };
  }, [activeTab, decodeState, compareState]);

  return (
    <div className="min-h-screen bg-[#0B0E14] text-[#F1F5F9] flex flex-col">
      {/* Strict 3-Zone Top Bar Contract */}
      <header
        ref={headerRef}
        className="border-b border-slate-800/80 bg-[#0B0E14] px-6 py-4 flex items-center justify-between gap-8"
      >
        {/* Zone 1: Single-line Wordmark */}
        <a
          href="#top"
          className="hero-entrance font-display text-lg font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0"
        >
          CTC Decoder
        </a>

        {/* Zone 2: Concise single-line navigation tabs */}
        <nav
          aria-label="Primary sections"
          className="hero-entrance hidden md:flex items-center gap-6 text-sm font-medium"
        >
          {TABS.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'border-[#D4A853] text-white'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Single primary action */}
        <div className="hero-entrance shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab(activeTab === 'chat' ? 'decode' : 'chat')}
            className="px-4 py-2 rounded-lg bg-[#D4A853] text-[#0B0E14] text-xs font-semibold hover:bg-[#e1b866] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {activeTab === 'chat' ? 'Back to Decoder' : 'Ask CTC Anna'}
          </button>
        </div>
      </header>

      {/* Mobile Tab Selector */}
      <div className="md:hidden border-b border-slate-800/80 px-4 py-2.5 flex items-center gap-2 overflow-x-auto">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === tab.id
                ? 'bg-[#D4A853] text-[#0B0E14]'
                : 'bg-[#121722] text-slate-300 border border-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Hero Editorial Lead */}
      <div className="max-w-[1440px] w-full mx-auto px-6 pt-6 pb-4">
        <div className="flex flex-wrap items-end justify-between gap-4 border-b border-slate-800/70 pb-5">
          <div className="max-w-2xl">
            <div className="text-xs text-[#D4A853] font-medium mb-1">
              Bengaluru Fresher Offer Ledger · Interactive 3D Compensation Vault
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-semibold tracking-tight text-slate-100 text-balance">
              Offer Letter to In-Hand Salary
            </h1>
          </div>
          <p className="text-xs text-slate-400 max-w-md leading-relaxed">
            Expose variable pay, employer PF, gratuity, and service bond traps. Hover or click any 3D layer to inspect
            how your CTC converts into guaranteed monthly cash.
          </p>
        </div>
      </div>

      {/* Main Split-Screen Interactive Stage + Workspace */}
      <main className="max-w-[1440px] w-full mx-auto px-6 pb-10 flex-1">
        <div
          className={`grid gap-6 items-start ${
            stageExpanded ? 'grid-cols-1' : 'grid-cols-1 lg:grid-cols-12'
          }`}
        >
          {/* Left / Sticky 3D Three.js Compensation Vault */}
          <div
            className={`${
              stageExpanded
                ? 'h-[72vh] min-h-[540px]'
                : 'lg:col-span-5 lg:sticky lg:top-6 h-[480px] lg:h-[calc(100vh-12rem)] min-h-[460px]'
            }`}
          >
            <SalaryVaultCanvas
              sceneData={vaultData}
              isExpanded={stageExpanded}
              onToggleExpand={() => setStageExpanded((v) => !v)}
            />
          </div>

          {/* Right Workspace */}
          {!stageExpanded && (
            <div className="lg:col-span-7">
              {activeTab === 'decode' && (
                <DecodeOfferTab
                  state={decodeState}
                  onChange={setDecodeState}
                  onRecalculate={handleRecalculateDecode}
                />
              )}

              {activeTab === 'compare' && (
                <CompareOffersTab
                  state={compareState}
                  onChange={setCompareState}
                  onCompare={handleCompare}
                />
              )}

              {activeTab === 'chat' && (
                <ChatAnnaTab
                  messages={chatMessages}
                  showAgentSteps={showAgentSteps}
                  onToggleShowSteps={() => setShowAgentSteps((v) => !v)}
                  onSendMessage={handleSendChat}
                  onClearChat={() => {
                    setChatMessages([]);
                    setChatError(null);
                  }}
                  sending={sendingChat}
                  error={chatError}
                />
              )}

              {activeTab === 'test' && <TestAgentTab />}

              {activeTab === 'how' && <HowItWorksTab />}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
