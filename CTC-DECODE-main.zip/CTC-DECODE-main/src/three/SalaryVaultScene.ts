import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

export type VaultMode = 'decode' | 'compare';
export type CameraPreset = 'overview' | 'core' | 'deductions' | 'compare';

export interface VaultSceneData {
  mode: VaultMode;
  company: string;
  ctcLakhs: number;
  basicPercent: number;
  variablePercent: number;
  monthly: {
    basic: number;
    hra: number;
    special_allowance: number;
    employer_pf: number;
    gratuity: number;
  };
  approxMonthlyBeforeTax: number;
  guaranteedMonthly: number;
  redFlags: string[];
  compare: {
    ctcA: number;
    varA: number;
    ctcB: number;
    varB: number;
    guaranteedA: number;
    guaranteedB: number;
    higher: 'A' | 'B' | 'same';
    difference: number;
  };
}

export interface InspectedSegment {
  id: string;
  label: string;
  category: 'In-Hand Component' | 'Locked Deduction' | 'Non-Guaranteed' | 'Restrictive Clause' | 'Offer Comparison';
  primaryValue: string;
  secondaryValue: string;
  description: string;
  accentHex: string;
}

export interface VaultSceneCallbacks {
  onInspect?: (segment: InspectedSegment | null) => void;
  onContextLost?: (lost: boolean) => void;
}

const _camGoal = new THREE.Vector3();
const _targetGoal = new THREE.Vector3();
const _mouseNdc = new THREE.Vector2();

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function createDialTexture(): THREE.CanvasTexture {
  const size = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const cx = size / 2;
    const cy = size / 2;

    ctx.fillStyle = '#111622';
    ctx.fillRect(0, 0, size, size);

    const grad = ctx.createRadialGradient(cx, cy, 40, cx, cy, size * 0.48);
    grad.addColorStop(0, '#1c2436');
    grad.addColorStop(0.7, '#111622');
    grad.addColorStop(1, '#090c12');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(cx, cy, size * 0.48, 0, Math.PI * 2);
    ctx.fill();

    // Concentric hairline rings
    ctx.strokeStyle = 'rgba(212, 168, 83, 0.25)';
    ctx.lineWidth = 2;
    [160, 260, 360, 440, 470].forEach((r) => {
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();
    });

    // Precision tick marks
    for (let i = 0; i < 72; i++) {
      const angle = (i / 72) * Math.PI * 2;
      const major = i % 6 === 0;
      const inner = major ? 410 : 426;
      const outer = 440;
      ctx.strokeStyle = major ? 'rgba(212, 168, 83, 0.7)' : 'rgba(148, 163, 184, 0.3)';
      ctx.lineWidth = major ? 3 : 1.5;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(angle) * inner, cy + Math.sin(angle) * inner);
      ctx.lineTo(cx + Math.cos(angle) * outer, cy + Math.sin(angle) * outer);
      ctx.stroke();
    }

    // Subtle quadrant crosshairs
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.14)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(cx - 440, cy);
    ctx.lineTo(cx + 440, cy);
    ctx.moveTo(cx, cy - 440);
    ctx.lineTo(cx, cy + 440);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const c = size / 2;
    const grad = ctx.createRadialGradient(c, c, 20, c, c, c);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.78)');
    grad.addColorStop(0.5, 'rgba(0, 0, 0, 0.35)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createBadgeTexture(label: string, accent: string): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const cx = size / 2;
    const cy = size / 2;
    ctx.fillStyle = '#121826';
    ctx.fillRect(0, 0, size, size);

    ctx.strokeStyle = accent;
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.arc(cx, cy, 215, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = '#e2e8f0';
    ctx.font = 'bold 150px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, cx, cy + 6);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

interface StackPart {
  id: string;
  mesh: THREE.Mesh;
  trim?: THREE.Mesh;
  targetHeight: number;
  currentHeight: number;
  targetY: number;
  currentY: number;
  baseColor: THREE.Color;
}

export class SalaryVaultScene {
  private container: HTMLElement;
  private callbacks: VaultSceneCallbacks;
  private isSoftwareGl: boolean;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private controls: OrbitControls;
  private pmremEnv: THREE.Texture;
  private raycaster = new THREE.Raycaster();
  private clock = new THREE.Clock();

  private frameId = 0;
  private disposed = false;
  private lastRaycastTime = 0;

  private plinthGroup = new THREE.Group();
  private decodeGroup = new THREE.Group();
  private compareGroup = new THREE.Group();
  private redFlagGroup = new THREE.Group();

  private spindleMesh!: THREE.Mesh;
  private variableGroup = new THREE.Group();
  private variablePrism!: THREE.Mesh;
  private variableWire!: THREE.Mesh;
  private stackParts: StackPart[] = [];
  private redFlagMeshes: THREE.Mesh[] = [];

  // Compare tower meshes
  private towerAGuaranteed!: THREE.Mesh;
  private towerAVariable!: THREE.Mesh;
  private towerBGuaranteed!: THREE.Mesh;
  private towerBVariable!: THREE.Mesh;
  private winnerHalo!: THREE.Mesh;
  private compareDeltaBridge!: THREE.Mesh;

  private interactiveMeshes: THREE.Object3D[] = [];
  private hoveredId: string | null = null;
  private selectedId: string | null = null;

  private explodedTarget = 0.25;
  private explodedCurrent = 0.25;
  private autoRotate = true;

  private cameraGlideActive = false;
  private activePreset: CameraPreset = 'overview';

  private data: VaultSceneData;
  private disposables: Array<{ dispose: () => void }> = [];

  constructor(container: HTMLElement, initialData: VaultSceneData, callbacks: VaultSceneCallbacks = {}) {
    this.container = container;
    this.data = initialData;
    this.callbacks = callbacks;
    this.isSoftwareGl = detectSoftwareWebGL();

    const width = Math.max(container.clientWidth, 320);
    const height = Math.max(container.clientHeight, 320);

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setClearColor(0x0b0e14, 1);

    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0b0e14);
    this.scene.fog = new THREE.FogExp2(0x0b0e14, 0.042);

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const roomEnv = new RoomEnvironment();
    this.pmremEnv = pmrem.fromScene(roomEnv, 0.04).texture;
    this.scene.environment = this.pmremEnv;
    roomEnv.dispose();
    pmrem.dispose();
    this.disposables.push(this.pmremEnv);

    this.camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 80);
    this.camera.position.set(4.6, 3.8, 5.8);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.06;
    this.controls.enablePan = false;
    this.controls.minDistance = 3.2;
    this.controls.maxDistance = 12.5;
    this.controls.minPolarAngle = 0.25;
    this.controls.maxPolarAngle = Math.PI * 0.47;
    this.controls.autoRotate = !this.isSoftwareGl && this.autoRotate;
    this.controls.autoRotateSpeed = 0.55;
    this.controls.target.set(0, 1.45, 0);

    this.controls.addEventListener('start', () => {
      this.cameraGlideActive = false;
    });

    this.raycaster.layers.set(1);

    this.buildLights();
    this.buildPlinth();
    this.buildDecodeStack();
    this.buildCompareTowers();
    this.applyDataToTargets(true);

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.tick();
  }

  private track<T extends { dispose: () => void }>(item: T): T {
    this.disposables.push(item);
    return item;
  }

  private buildLights() {
    const hemi = new THREE.HemisphereLight(0x93c5fd, 0x1e293b, 0.75);
    this.scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(0xfff1d6, 2.1);
    keyLight.position.set(5.5, 9.0, 5.5);
    keyLight.castShadow = !this.isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 25;
    const d = 4.5;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    this.scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x60a5fa, 1.1);
    rimLight.position.set(-5.0, 4.5, -5.0);
    this.scene.add(rimLight);

    const warmFill = new THREE.PointLight(0xd4a853, 0.9, 14, 1.5);
    warmFill.position.set(0, 2.2, 3.2);
    this.scene.add(warmFill);
  }

  private buildPlinth() {
    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();

    // Soft radial contact shadow
    const shadowTex = this.track(createContactShadowTexture());
    const shadowPlane = new THREE.Mesh(
      this.track(new THREE.PlaneGeometry(8.8, 8.8)),
      this.track(
        new THREE.MeshBasicMaterial({
          map: shadowTex,
          transparent: true,
          depthWrite: false,
          opacity: 0.7,
        }),
      ),
    );
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = -0.02;
    this.plinthGroup.add(shadowPlane);

    // Architectural studio floor disc
    const floorMat = this.track(
      new THREE.MeshStandardMaterial({
        color: 0x0f141e,
        roughness: 0.85,
        metalness: 0.15,
      }),
    );
    const floorDisc = new THREE.Mesh(this.track(new THREE.CylinderGeometry(5.6, 5.8, 0.08, 64)), floorMat);
    floorDisc.position.y = -0.06;
    floorDisc.receiveShadow = true;
    this.plinthGroup.add(floorDisc);

    // Lower brushed obsidian plinth
    const plinthBaseMat = this.track(
      new THREE.MeshStandardMaterial({
        color: 0x161c2a,
        roughness: 0.42,
        metalness: 0.65,
      }),
    );
    const plinthBase = new THREE.Mesh(this.track(new THREE.CylinderGeometry(2.55, 2.75, 0.22, 48)), plinthBaseMat);
    plinthBase.position.y = 0.09;
    plinthBase.castShadow = true;
    plinthBase.receiveShadow = true;
    this.plinthGroup.add(plinthBase);

    // Brass chamfer bezel ring
    const brassMat = this.track(
      new THREE.MeshStandardMaterial({
        color: 0xd4a853,
        roughness: 0.24,
        metalness: 0.92,
      }),
    );
    const bezel = new THREE.Mesh(this.track(new THREE.TorusGeometry(2.52, 0.032, 16, 64)), brassMat);
    bezel.rotation.x = Math.PI / 2;
    bezel.position.y = 0.2;
    this.plinthGroup.add(bezel);

    // Precision dial plate
    const dialTex = this.track(createDialTexture());
    dialTex.anisotropy = maxAniso;
    const dialMat = this.track(
      new THREE.MeshStandardMaterial({
        map: dialTex,
        roughness: 0.52,
        metalness: 0.25,
        polygonOffset: true,
        polygonOffsetFactor: -1,
        polygonOffsetUnits: -1,
      }),
    );
    const dialPlate = new THREE.Mesh(this.track(new THREE.CylinderGeometry(2.44, 2.44, 0.03, 48)), dialMat);
    dialPlate.position.y = 0.21;
    dialPlate.receiveShadow = true;
    this.plinthGroup.add(dialPlate);

    this.scene.add(this.plinthGroup);
  }

  private buildDecodeStack() {
    // Central telescoping spindle rod
    const spindleMat = this.track(
      new THREE.MeshStandardMaterial({
        color: 0x94a3b8,
        metalness: 0.9,
        roughness: 0.2,
      }),
    );
    this.spindleMesh = new THREE.Mesh(this.track(new THREE.CylinderGeometry(0.11, 0.11, 1, 24)), spindleMat);
    this.spindleMesh.position.y = 0.23;
    this.decodeGroup.add(this.spindleMesh);

    const segmentSpecs = [
      { id: 'basic', radiusTop: 1.08, radiusBot: 1.12, color: 0xd4a853, metalness: 0.86, roughness: 0.22 },
      { id: 'hra', radiusTop: 1.0, radiusBot: 1.03, color: 0x10b981, metalness: 0.45, roughness: 0.34 },
      { id: 'special', radiusTop: 0.93, radiusBot: 0.96, color: 0x3b82f6, metalness: 0.38, roughness: 0.4 },
      { id: 'pf', radiusTop: 0.84, radiusBot: 0.87, color: 0xf59e0b, metalness: 0.68, roughness: 0.28 },
      { id: 'gratuity', radiusTop: 0.77, radiusBot: 0.8, color: 0x94a3b8, metalness: 0.78, roughness: 0.25 },
    ];

    segmentSpecs.forEach((spec) => {
      const geo = this.track(new THREE.CylinderGeometry(spec.radiusTop, spec.radiusBot, 1, 40));
      const mat = this.track(
        new THREE.MeshPhysicalMaterial({
          color: spec.color,
          metalness: spec.metalness,
          roughness: spec.roughness,
          clearcoat: 0.4,
          clearcoatRoughness: 0.25,
        }),
      );
      const mesh = new THREE.Mesh(geo, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.layers.enable(1);

      // Thin metallic rim accent around top edge
      const trimGeo = this.track(new THREE.TorusGeometry(spec.radiusTop, 0.016, 10, 48));
      const trimMat = this.track(
        new THREE.MeshStandardMaterial({
          color: 0xe2e8f0,
          metalness: 0.9,
          roughness: 0.22,
        }),
      );
      const trim = new THREE.Mesh(trimGeo, trimMat);
      trim.rotation.x = Math.PI / 2;
      trim.position.y = 0.5;
      mesh.add(trim);

      this.decodeGroup.add(mesh);
      this.interactiveMeshes.push(mesh);

      this.stackParts.push({
        id: spec.id,
        mesh,
        trim,
        targetHeight: 0.5,
        currentHeight: 0.5,
        targetY: 0.5,
        currentY: 0.5,
        baseColor: new THREE.Color(spec.color),
      });
    });

    // Floating Variable Pay Crown
    const varGeo = this.track(new THREE.CylinderGeometry(0.66, 0.72, 1, 8));
    const varMat = this.track(
      new THREE.MeshPhysicalMaterial({
        color: 0xe06d53,
        metalness: 0.18,
        roughness: 0.14,
        transmission: this.isSoftwareGl ? 0 : 0.72,
        transparent: true,
        opacity: this.isSoftwareGl ? 0.58 : 0.94,
        ior: 1.52,
        thickness: 0.8,
        clearcoat: 1.0,
      }),
    );
    this.variablePrism = new THREE.Mesh(varGeo, varMat);
    this.variablePrism.castShadow = true;
    this.variablePrism.layers.enable(1);

    const wireGeo = this.track(new THREE.CylinderGeometry(0.67, 0.73, 1.01, 8));
    const wireMat = this.track(
      new THREE.MeshBasicMaterial({
        color: 0xfca5a5,
        wireframe: true,
        transparent: true,
        opacity: 0.32,
      }),
    );
    this.variableWire = new THREE.Mesh(wireGeo, wireMat);
    this.variablePrism.add(this.variableWire);

    this.variableGroup.add(this.variablePrism);
    this.decodeGroup.add(this.variableGroup);
    this.interactiveMeshes.push(this.variablePrism);

    // Red Flag Orbiting Beacons (max 5)
    const beaconGeo = this.track(new THREE.OctahedronGeometry(0.14, 0));
    for (let i = 0; i < 5; i++) {
      const beaconMat = this.track(
        new THREE.MeshStandardMaterial({
          color: 0xef4444,
          emissive: 0x7f1d1d,
          emissiveIntensity: 0.55,
          metalness: 0.5,
          roughness: 0.25,
        }),
      );
      const beacon = new THREE.Mesh(beaconGeo, beaconMat);
      beacon.layers.enable(1);
      beacon.visible = false;
      this.redFlagGroup.add(beacon);
      this.redFlagMeshes.push(beacon);
      this.interactiveMeshes.push(beacon);
    }
    this.decodeGroup.add(this.redFlagGroup);

    this.scene.add(this.decodeGroup);
  }

  private buildCompareTowers() {
    const createSubPedestal = (x: number, label: string, accent: string) => {
      const ped = new THREE.Mesh(
        this.track(new THREE.CylinderGeometry(0.86, 0.94, 0.14, 36)),
        this.track(new THREE.MeshStandardMaterial({ color: 0x1a2234, metalness: 0.6, roughness: 0.35 })),
      );
      ped.position.set(x, 0.29, 0);
      ped.receiveShadow = true;
      this.compareGroup.add(ped);

      const badgeTex = this.track(createBadgeTexture(label, accent));
      badgeTex.anisotropy = this.renderer.capabilities.getMaxAnisotropy();
      const badge = new THREE.Mesh(
        this.track(new THREE.CylinderGeometry(0.45, 0.45, 0.02, 32)),
        this.track(
          new THREE.MeshStandardMaterial({
            map: badgeTex,
            roughness: 0.4,
            metalness: 0.2,
            polygonOffset: true,
            polygonOffsetFactor: -1,
          }),
        ),
      );
      badge.position.set(x, 0.36, 0.95);
      badge.rotation.x = Math.PI * 0.25;
      this.compareGroup.add(badge);
    };

    createSubPedestal(-1.32, 'A', '#d4a853');
    createSubPedestal(1.32, 'B', '#10b981');

    const guarAMat = this.track(
      new THREE.MeshPhysicalMaterial({
        color: 0xd4a853,
        metalness: 0.82,
        roughness: 0.24,
        clearcoat: 0.35,
      }),
    );
    this.towerAGuaranteed = new THREE.Mesh(this.track(new THREE.CylinderGeometry(0.56, 0.62, 1, 32)), guarAMat);
    this.towerAGuaranteed.position.set(-1.32, 0.86, 0);
    this.towerAGuaranteed.castShadow = true;
    this.towerAGuaranteed.layers.enable(1);
    this.compareGroup.add(this.towerAGuaranteed);
    this.interactiveMeshes.push(this.towerAGuaranteed);

    const guarBMat = this.track(
      new THREE.MeshPhysicalMaterial({
        color: 0x10b981,
        metalness: 0.62,
        roughness: 0.28,
        clearcoat: 0.35,
      }),
    );
    this.towerBGuaranteed = new THREE.Mesh(this.track(new THREE.CylinderGeometry(0.56, 0.62, 1, 32)), guarBMat);
    this.towerBGuaranteed.position.set(1.32, 0.86, 0);
    this.towerBGuaranteed.castShadow = true;
    this.towerBGuaranteed.layers.enable(1);
    this.compareGroup.add(this.towerBGuaranteed);
    this.interactiveMeshes.push(this.towerBGuaranteed);

    const varMatA = this.track(
      new THREE.MeshPhysicalMaterial({
        color: 0xe06d53,
        metalness: 0.2,
        roughness: 0.16,
        transparent: true,
        opacity: 0.56,
      }),
    );
    this.towerAVariable = new THREE.Mesh(this.track(new THREE.CylinderGeometry(0.5, 0.54, 1, 8)), varMatA);
    this.towerAVariable.position.set(-1.32, 2.0, 0);
    this.towerAVariable.layers.enable(1);
    this.compareGroup.add(this.towerAVariable);
    this.interactiveMeshes.push(this.towerAVariable);

    const varMatB = varMatA.clone();
    this.track(varMatB);
    this.towerBVariable = new THREE.Mesh(this.track(new THREE.CylinderGeometry(0.5, 0.54, 1, 8)), varMatB);
    this.towerBVariable.position.set(1.32, 2.0, 0);
    this.towerBVariable.layers.enable(1);
    this.compareGroup.add(this.towerBVariable);
    this.interactiveMeshes.push(this.towerBVariable);

    // Winner Halo Ring
    this.winnerHalo = new THREE.Mesh(
      this.track(new THREE.TorusGeometry(0.84, 0.035, 14, 48)),
      this.track(
        new THREE.MeshStandardMaterial({
          color: 0xfde68a,
          emissive: 0xd4a853,
          emissiveIntensity: 0.65,
          metalness: 0.9,
          roughness: 0.18,
        }),
      ),
    );
    this.winnerHalo.rotation.x = Math.PI / 2;
    this.winnerHalo.position.set(1.32, 0.42, 0);
    this.compareGroup.add(this.winnerHalo);

    // Subtle horizontal delta bridge
    this.compareDeltaBridge = new THREE.Mesh(
      this.track(new THREE.BoxGeometry(2.64, 0.015, 0.18)),
      this.track(
        new THREE.MeshBasicMaterial({
          color: 0x38bdf8,
          transparent: true,
          opacity: 0.35,
        }),
      ),
    );
    this.compareGroup.add(this.compareDeltaBridge);

    this.compareGroup.visible = false;
    this.scene.add(this.compareGroup);
  }

  public updateData(newData: VaultSceneData) {
    const modeChanged = this.data.mode !== newData.mode;
    this.data = newData;
    this.applyDataToTargets(false);
    if (modeChanged) {
      this.setCameraPreset(newData.mode === 'compare' ? 'compare' : 'overview');
    }
  }

  public setExploded(value: number) {
    this.explodedTarget = THREE.MathUtils.clamp(value, 0, 1);
  }

  public setAutoRotate(enabled: boolean) {
    this.autoRotate = enabled;
    this.controls.autoRotate = !this.isSoftwareGl && enabled;
  }

  public setCameraPreset(preset: CameraPreset) {
    this.activePreset = preset;
    this.cameraGlideActive = true;
    if (preset === 'overview') {
      _camGoal.set(4.5, 3.6, 5.6);
      _targetGoal.set(0, 1.45, 0);
    } else if (preset === 'core') {
      _camGoal.set(2.9, 1.55, 3.3);
      _targetGoal.set(0, 1.0, 0);
    } else if (preset === 'deductions') {
      _camGoal.set(3.2, 2.85, 3.1);
      _targetGoal.set(0, 2.05, 0);
    } else if (preset === 'compare') {
      _camGoal.set(0.2, 3.1, 6.2);
      _targetGoal.set(0, 1.45, 0);
    }
  }

  private applyDataToTargets(immediate: boolean) {
    const isCompare = this.data.mode === 'compare';
    this.decodeGroup.visible = !isCompare;
    this.compareGroup.visible = isCompare;

    const totalMonthly = Math.max(
      this.data.monthly.basic +
        this.data.monthly.hra +
        this.data.monthly.special_allowance +
        this.data.monthly.employer_pf +
        this.data.monthly.gratuity,
      1,
    );

    const totalScaleHeight = 2.65;
    const minH = 0.14;
    const shares = [
      this.data.monthly.basic / totalMonthly,
      this.data.monthly.hra / totalMonthly,
      this.data.monthly.special_allowance / totalMonthly,
      this.data.monthly.employer_pf / totalMonthly,
      this.data.monthly.gratuity / totalMonthly,
    ];

    const inspectMap: Record<string, InspectedSegment> = {
      basic: {
        id: 'basic',
        label: 'Basic Salary',
        category: 'In-Hand Component',
        primaryValue: `₹${this.data.monthly.basic.toLocaleString('en-IN')}/mo`,
        secondaryValue: `${Math.round(shares[0] * 100)}% of monthly CTC`,
        description: 'Taxable fixed core. Drives your PF, Gratuity, and HRA limits.',
        accentHex: '#D4A853',
      },
      hra: {
        id: 'hra',
        label: 'House Rent Allowance (HRA)',
        category: 'In-Hand Component',
        primaryValue: `₹${this.data.monthly.hra.toLocaleString('en-IN')}/mo`,
        secondaryValue: '50% of Basic (demo formula)',
        description: 'Part of monthly gross pay; eligible for rent exemption under old tax regime.',
        accentHex: '#10B981',
      },
      special: {
        id: 'special',
        label: 'Special Allowance',
        category: 'In-Hand Component',
        primaryValue: `₹${this.data.monthly.special_allowance.toLocaleString('en-IN')}/mo`,
        secondaryValue: `${Math.round(shares[2] * 100)}% of monthly CTC`,
        description: 'Balancing component paid monthly in full before income tax.',
        accentHex: '#3B82F6',
      },
      pf: {
        id: 'pf',
        label: 'Employer PF Contribution',
        category: 'Locked Deduction',
        primaryValue: `₹${this.data.monthly.employer_pf.toLocaleString('en-IN')}/mo`,
        secondaryValue: '12% of Basic (capped at ₹15k/mo)',
        description: 'Goes into your EPF retirement account — part of CTC, NOT monthly take-home.',
        accentHex: '#F59E0B',
      },
      gratuity: {
        id: 'gratuity',
        label: 'Gratuity Accrual',
        category: 'Locked Deduction',
        primaryValue: `₹${this.data.monthly.gratuity.toLocaleString('en-IN')}/mo`,
        secondaryValue: '4.81% of Basic',
        description: 'Typically vested only after completing 5 continuous years at the company.',
        accentHex: '#94A3B8',
      },
    };

    let runningY = 0.24;
    const gap = 0.04 + this.explodedCurrent * 0.28;

    this.stackParts.forEach((part, idx) => {
      const h = Math.max(minH, shares[idx] * totalScaleHeight);
      part.targetHeight = h;
      part.targetY = runningY + h / 2;
      part.mesh.userData.inspectInfo = inspectMap[part.id];
      if (immediate) {
        part.currentHeight = h;
        part.currentY = part.targetY;
      }
      runningY += h + gap;
    });

    // Variable crown metadata
    const varYearly = Math.round((this.data.ctcLakhs * 100000 * this.data.variablePercent) / 100);
    const varMonthly = Math.round(varYearly / 12);
    this.variablePrism.userData.inspectInfo = {
      id: 'variable',
      label: 'Variable Pay (At-Risk)',
      category: 'Non-Guaranteed',
      primaryValue: `₹${varYearly.toLocaleString('en-IN')}/yr`,
      secondaryValue: `${this.data.variablePercent}% of CTC (≈ ₹${varMonthly.toLocaleString('en-IN')}/mo)`,
      description: 'Linked to performance or company targets. Exclude this when budgeting fixed rent or EMIs.',
      accentHex: '#E06D53',
    } satisfies InspectedSegment;

    // Red flag beacons
    const flags = this.data.redFlags || [];
    this.redFlagMeshes.forEach((beacon, idx) => {
      if (idx < flags.length) {
        beacon.visible = true;
        beacon.userData.inspectInfo = {
          id: `flag-${idx}`,
          label: `Clause Alert #${idx + 1}`,
          category: 'Restrictive Clause',
          primaryValue: `${this.data.company || 'Offer Clause'}`,
          secondaryValue: 'Verify exit terms with HR',
          description: flags[idx],
          accentHex: '#EF4444',
        } satisfies InspectedSegment;
      } else {
        beacon.visible = false;
      }
    });

    // Compare mode metadata
    const cmp = this.data.compare;
    this.towerAGuaranteed.userData.inspectInfo = {
      id: 'cmp-a-guar',
      label: 'Offer A · Guaranteed Pay',
      category: 'Offer Comparison',
      primaryValue: `₹${cmp.guaranteedA.toLocaleString('en-IN')}/yr`,
      secondaryValue: `${cmp.ctcA} LPA (${100 - cmp.varA}% fixed)`,
      description: 'Certain fixed annual compensation excluding variable performance pay.',
      accentHex: '#D4A853',
    } satisfies InspectedSegment;

    this.towerBGuaranteed.userData.inspectInfo = {
      id: 'cmp-b-guar',
      label: 'Offer B · Guaranteed Pay',
      category: 'Offer Comparison',
      primaryValue: `₹${cmp.guaranteedB.toLocaleString('en-IN')}/yr`,
      secondaryValue: `${cmp.ctcB} LPA (${100 - cmp.varB}% fixed)`,
      description: 'Certain fixed annual compensation excluding variable performance pay.',
      accentHex: '#10B981',
    } satisfies InspectedSegment;

    const varAYr = Math.max(0, Math.round(cmp.ctcA * 100000 - cmp.guaranteedA));
    const varBYr = Math.max(0, Math.round(cmp.ctcB * 100000 - cmp.guaranteedB));

    this.towerAVariable.userData.inspectInfo = {
      id: 'cmp-a-var',
      label: 'Offer A · Variable Risk',
      category: 'Non-Guaranteed',
      primaryValue: `₹${varAYr.toLocaleString('en-IN')}/yr`,
      secondaryValue: `${cmp.varA}% variable share`,
      description: 'Floating compensation at risk depending on appraisal or company revenue.',
      accentHex: '#E06D53',
    } satisfies InspectedSegment;

    this.towerBVariable.userData.inspectInfo = {
      id: 'cmp-b-var',
      label: 'Offer B · Variable Risk',
      category: 'Non-Guaranteed',
      primaryValue: `₹${varBYr.toLocaleString('en-IN')}/yr`,
      secondaryValue: `${cmp.varB}% variable share`,
      description: 'Floating compensation at risk depending on appraisal or company revenue.',
      accentHex: '#E06D53',
    } satisfies InspectedSegment;
  }

  private handlePointerMove = (e: PointerEvent) => {
    if (this.disposed) return;
    const now = performance.now();
    if (now - this.lastRaycastTime < 45) return;
    this.lastRaycastTime = now;

    const rect = this.renderer.domElement.getBoundingClientRect();
    _mouseNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    _mouseNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(_mouseNdc, this.camera);
    const hits = this.raycaster.intersectObjects(this.interactiveMeshes, false).filter((h) => {
      let obj: THREE.Object3D | null = h.object;
      while (obj) {
        if (!obj.visible) return false;
        obj = obj.parent;
      }
      return true;
    });

    if (hits.length > 0) {
      const hitObj = hits[0].object;
      const info = hitObj.userData.inspectInfo as InspectedSegment | undefined;
      if (info && info.id !== this.hoveredId) {
        this.hoveredId = info.id;
        this.renderer.domElement.style.cursor = 'pointer';
        if (!this.selectedId) {
          this.callbacks.onInspect?.(info);
        }
      }
    } else if (this.hoveredId !== null) {
      this.hoveredId = null;
      this.renderer.domElement.style.cursor = 'grab';
      if (!this.selectedId) {
        this.callbacks.onInspect?.(null);
      }
    }
  };

  private handlePointerClick = (e: MouseEvent) => {
    if (this.disposed) return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    _mouseNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    _mouseNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(_mouseNdc, this.camera);
    const hits = this.raycaster.intersectObjects(this.interactiveMeshes, false).filter((h) => {
      let obj: THREE.Object3D | null = h.object;
      while (obj) {
        if (!obj.visible) return false;
        obj = obj.parent;
      }
      return true;
    });

    if (hits.length > 0) {
      const info = hits[0].object.userData.inspectInfo as InspectedSegment | undefined;
      if (info) {
        if (this.selectedId === info.id) {
          this.selectedId = null;
          this.callbacks.onInspect?.(null);
        } else {
          this.selectedId = info.id;
          this.callbacks.onInspect?.(info);
        }
      }
    } else if (this.selectedId) {
      this.selectedId = null;
      this.callbacks.onInspect?.(null);
    }
  };

  private handleResize = () => {
    if (this.disposed) return;
    const width = Math.max(this.container.clientWidth, 320);
    const height = Math.max(this.container.clientHeight, 320);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private handleContextLost = (e: Event) => {
    e.preventDefault();
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    this.callbacks.onContextLost?.(true);
  };

  private handleContextRestored = () => {
    this.callbacks.onContextLost?.(false);
    this.tick();
  };

  private bindEvents() {
    window.addEventListener('resize', this.handleResize);
    this.renderer.domElement.addEventListener('pointermove', this.handlePointerMove);
    this.renderer.domElement.addEventListener('click', this.handlePointerClick);
    this.renderer.domElement.addEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.addEventListener('webglcontextrestored', this.handleContextRestored);
    this.renderer.domElement.style.cursor = 'grab';
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick = () => {
    if (this.disposed) return;
    const delta = Math.min(this.clock.getDelta(), 0.1);
    const elapsed = this.clock.getElapsedTime();

    // Smoothly damp exploded factor
    this.explodedCurrent = THREE.MathUtils.damp(this.explodedCurrent, this.explodedTarget, 6.5, delta);

    // Recompute stack targets smoothly with exploded spacing
    const gap = 0.03 + this.explodedCurrent * 0.26;
    let runningY = 0.24;
    for (const part of this.stackParts) {
      part.currentHeight = THREE.MathUtils.damp(part.currentHeight, part.targetHeight, 7.5, delta);
      const targetY = runningY + part.currentHeight / 2;
      part.currentY = THREE.MathUtils.damp(part.currentY, targetY, 7.5, delta);
      part.mesh.scale.set(1, part.currentHeight, 1);
      part.mesh.position.y = part.currentY;

      const isActive = this.selectedId === part.id || this.hoveredId === part.id;
      const mat = part.mesh.material as THREE.MeshPhysicalMaterial;
      const targetEmissive = isActive ? 0.35 : 0.02;
      mat.emissive.copy(part.baseColor);
      mat.emissiveIntensity = THREE.MathUtils.damp(mat.emissiveIntensity, targetEmissive, 10, delta);

      runningY += part.currentHeight + gap;
    }

    // Spindle matches full height of fixed stack
    const spindleHeight = Math.max(0.4, runningY - 0.18);
    this.spindleMesh.scale.set(1, spindleHeight, 1);
    this.spindleMesh.position.y = 0.22 + spindleHeight / 2;

    // Floating variable crown
    const varPct = this.data.variablePercent;
    if (varPct > 0.2) {
      this.variableGroup.visible = true;
      const varH = THREE.MathUtils.clamp((varPct / 100) * 2.4, 0.18, 1.1);
      this.variablePrism.scale.set(1, varH, 1);
      const hoverLift = 0.32 + this.explodedCurrent * 0.3 + Math.sin(elapsed * 2.1) * 0.055;
      this.variableGroup.position.y = runningY + hoverLift + varH / 2;
      this.variableGroup.rotation.y = elapsed * 0.35;
      const varMat = this.variablePrism.material as THREE.MeshPhysicalMaterial;
      const varActive = this.selectedId === 'variable' || this.hoveredId === 'variable';
      varMat.emissive.setHex(0xe06d53);
      varMat.emissiveIntensity = THREE.MathUtils.damp(varMat.emissiveIntensity, varActive ? 0.45 : 0.12, 10, delta);
    } else {
      this.variableGroup.visible = false;
    }

    // Orbiting Red Flag Beacons
    const activeFlags = this.redFlagMeshes.filter((m) => m.visible);
    activeFlags.forEach((beacon, idx) => {
      const angle = elapsed * 0.65 + (idx / Math.max(activeFlags.length, 1)) * Math.PI * 2;
      const radius = 1.62 + this.explodedCurrent * 0.18;
      beacon.position.set(
        Math.cos(angle) * radius,
        runningY + 0.15 + Math.sin(elapsed * 2.4 + idx) * 0.12,
        Math.sin(angle) * radius,
      );
      beacon.rotation.y = elapsed * 1.4;
      beacon.rotation.x = Math.sin(elapsed + idx) * 0.3;
    });

    // Compare Dual Towers animation
    if (this.compareGroup.visible) {
      const cmp = this.data.compare;
      const maxTotal = Math.max(cmp.ctcA * 100000, cmp.ctcB * 100000, 100000);
      const maxHeight = 2.85;

      const hGuarA = Math.max(0.18, (cmp.guaranteedA / maxTotal) * maxHeight);
      const hGuarB = Math.max(0.18, (cmp.guaranteedB / maxTotal) * maxHeight);
      const varAYr = Math.max(0, cmp.ctcA * 100000 - cmp.guaranteedA);
      const varBYr = Math.max(0, cmp.ctcB * 100000 - cmp.guaranteedB);
      const hVarA = varAYr > 0 ? Math.max(0.12, (varAYr / maxTotal) * maxHeight) : 0;
      const hVarB = varBYr > 0 ? Math.max(0.12, (varBYr / maxTotal) * maxHeight) : 0;

      const curGA = THREE.MathUtils.damp(this.towerAGuaranteed.scale.y, hGuarA, 7, delta);
      const curGB = THREE.MathUtils.damp(this.towerBGuaranteed.scale.y, hGuarB, 7, delta);
      this.towerAGuaranteed.scale.set(1, curGA, 1);
      this.towerAGuaranteed.position.y = 0.36 + curGA / 2;

      this.towerBGuaranteed.scale.set(1, curGB, 1);
      this.towerBGuaranteed.position.y = 0.36 + curGB / 2;

      this.towerAVariable.visible = hVarA > 0;
      if (this.towerAVariable.visible) {
        const curVA = THREE.MathUtils.damp(this.towerAVariable.scale.y, hVarA, 7, delta);
        this.towerAVariable.scale.set(1, curVA, 1);
        this.towerAVariable.position.y = 0.36 + curGA + 0.16 + this.explodedCurrent * 0.25 + curVA / 2 + Math.sin(elapsed * 2) * 0.04;
        this.towerAVariable.rotation.y = elapsed * 0.35;
      }

      this.towerBVariable.visible = hVarB > 0;
      if (this.towerBVariable.visible) {
        const curVB = THREE.MathUtils.damp(this.towerBVariable.scale.y, hVarB, 7, delta);
        this.towerBVariable.scale.set(1, curVB, 1);
        this.towerBVariable.position.y = 0.36 + curGB + 0.16 + this.explodedCurrent * 0.25 + curVB / 2 + Math.sin(elapsed * 2 + 1) * 0.04;
        this.towerBVariable.rotation.y = -elapsed * 0.35;
      }

      // Winner Halo
      if (cmp.higher === 'A' || cmp.higher === 'B') {
        this.winnerHalo.visible = true;
        const targetX = cmp.higher === 'A' ? -1.32 : 1.32;
        const targetTopY = 0.36 + (cmp.higher === 'A' ? curGA : curGB) + 0.04;
        this.winnerHalo.position.x = THREE.MathUtils.damp(this.winnerHalo.position.x, targetX, 8, delta);
        this.winnerHalo.position.y = THREE.MathUtils.damp(this.winnerHalo.position.y, targetTopY, 8, delta);
      } else {
        this.winnerHalo.visible = false;
      }

      this.compareDeltaBridge.position.y = 0.36 + Math.min(curGA, curGB);
    }

    // Smooth camera preset glide
    if (this.cameraGlideActive) {
      this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, _camGoal.x, 5.5, delta);
      this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, _camGoal.y, 5.5, delta);
      this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, _camGoal.z, 5.5, delta);

      this.controls.target.x = THREE.MathUtils.damp(this.controls.target.x, _targetGoal.x, 5.5, delta);
      this.controls.target.y = THREE.MathUtils.damp(this.controls.target.y, _targetGoal.y, 5.5, delta);
      this.controls.target.z = THREE.MathUtils.damp(this.controls.target.z, _targetGoal.z, 5.5, delta);

      if (this.camera.position.distanceTo(_camGoal) < 0.04 && this.controls.target.distanceTo(_targetGoal) < 0.04) {
        this.cameraGlideActive = false;
      }
    }

    this.controls.update();
    this.renderer.render(this.scene, this.camera);

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  public getActivePreset(): CameraPreset {
    return this.activePreset;
  }

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    window.removeEventListener('resize', this.handleResize);
    this.renderer.domElement.removeEventListener('pointermove', this.handlePointerMove);
    this.renderer.domElement.removeEventListener('click', this.handlePointerClick);
    this.renderer.domElement.removeEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.removeEventListener('webglcontextrestored', this.handleContextRestored);

    this.controls.dispose();
    for (const d of this.disposables) {
      d.dispose();
    }
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
