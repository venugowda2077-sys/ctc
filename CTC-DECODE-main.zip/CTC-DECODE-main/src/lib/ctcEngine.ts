export interface MonthlyBreakup {
  basic: number;
  hra: number;
  special_allowance: number;
  employer_pf: number;
  gratuity: number;
}

export interface CtcBreakupResult {
  ctc_yearly?: number;
  monthly?: MonthlyBreakup;
  approx_monthly_before_income_tax?: number;
  note?: string;
  error?: string;
}

export interface VariableImpactResult {
  variable_yearly: number;
  guaranteed_yearly: number;
  guaranteed_monthly: number;
}

export interface OfferComparisonResult {
  offer_a_guaranteed: number;
  offer_b_guaranteed: number;
  higher: 'A' | 'B' | 'same';
  difference: number;
}

export interface ExtractedOffer {
  company: string;
  ctc_lakhs: number;
  variable_percent: number;
  joining_bonus: number;
  notice_period_days: number;
  red_flags: string[];
}

export interface AgentStep {
  tool: 'ctc_breakup' | 'variable_impact' | 'compare_offers';
  inputs: Record<string, number>;
  result: CtcBreakupResult | VariableImpactResult | OfferComparisonResult | { error: string };
}

export interface TestCase {
  question: string;
  wantTools: Array<'ctc_breakup' | 'variable_impact' | 'compare_offers'>;
  wantInputs: Record<string, number>;
}

export function numberFrom(value: unknown, fallback = 0): number {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  const cleaned = String(value ?? '').replace(/,/g, '');
  const match = cleaned.match(/-?\d+\.?\d*/);
  if (!match) return fallback;
  const parsed = Number(match[0]);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export function formatINR(amount: number): string {
  const safe = Number.isFinite(amount) ? Math.round(amount) : 0;
  return `₹${safe.toLocaleString('en-IN')}`;
}

export function ctcBreakup(ctcLakhs: number | string, basicPercent: number | string): CtcBreakupResult {
  const ctc = numberFrom(ctcLakhs, 0) * 100000;
  if (ctc <= 0) {
    return { error: 'CTC must be more than zero.' };
  }
  const clampedBasicPct = Math.min(Math.max(numberFrom(basicPercent, 40), 20), 60);
  const basic = (ctc * clampedBasicPct) / 100;
  const hra = basic * 0.5;
  const employerPf = Math.min(basic, 180000) * 0.12;
  const gratuity = basic * 0.0481;
  const gross = ctc - employerPf - gratuity;

  const monthly: MonthlyBreakup = {
    basic: Math.round(basic / 12),
    hra: Math.round(hra / 12),
    special_allowance: Math.round((gross - basic - hra) / 12),
    employer_pf: Math.round(employerPf / 12),
    gratuity: Math.round(gratuity / 12),
  };

  return {
    ctc_yearly: Math.round(ctc),
    monthly,
    approx_monthly_before_income_tax: Math.round((gross - employerPf) / 12 - 200),
    note: 'Demo formula: HRA 50% of basic, PF 12% of basic up to Rs 15,000 a month, gratuity 4.81% of basic, professional tax Rs 200. Real offers differ.',
  };
}

export function variableImpact(ctcLakhs: number | string, variablePercent: number | string): VariableImpactResult {
  const ctc = Math.max(0, numberFrom(ctcLakhs, 0) * 100000);
  const clampedVarPct = Math.min(Math.max(numberFrom(variablePercent, 0), 0), 100);
  const variable = (ctc * clampedVarPct) / 100;
  const guaranteed = ctc - variable;

  return {
    variable_yearly: Math.round(variable),
    guaranteed_yearly: Math.round(guaranteed),
    guaranteed_monthly: Math.round(guaranteed / 12),
  };
}

export function compareOffers(
  ctcALakhs: number | string,
  variableAPercent: number | string,
  ctcBLakhs: number | string,
  variableBPercent: number | string,
): OfferComparisonResult {
  const a = variableImpact(ctcALakhs, variableAPercent).guaranteed_yearly;
  const b = variableImpact(ctcBLakhs, variableBPercent).guaranteed_yearly;
  return {
    offer_a_guaranteed: a,
    offer_b_guaranteed: b,
    higher: a > b ? 'A' : b > a ? 'B' : 'same',
    difference: Math.abs(a - b),
  };
}

export const RULES = `You are CTC Anna, a friendly money guide for freshers in Bengaluru.
- Use ctc_breakup, variable_impact and compare_offers for every number. NEVER do salary arithmetic yourself.
- Say clearly that these are demo formulas and the student should confirm the real salary breakup with HR.
- Keep answers short and simple. If no tool can help, say so honestly.`;

export const SYSTEM_OFFER = `Role: You are a careful assistant who reads job offer letters for a student.
Task: Pull the key numbers and red flags out of the offer letter.
Context: Use only what is written. If a number is missing use 0. variable_percent is the share of CTC that is variable pay. red_flags are only things literally in the letter, such as a service bond, a training deposit, a joining bonus clawback or a notice buyout. Use an empty list if there are none. Never invent anything.
Format: Fill the form. ctc_lakhs is the yearly CTC in lakhs (6.5 for Rs 6.5 lakhs).`;

export const SYSTEM_EXPLAIN = `Role: You are a friendly money guide for a fresher.
Task: Explain this job offer in plain English.
Context: You get numbers already calculated by the calculator. Use ONLY those numbers. Do not calculate anything yourself. Mention each red flag once.
Format: Exactly 4 short sentences, then one question the student should ask HR.`;

export interface SampleOfferPreset {
  id: string;
  label: string;
  text: string;
}

export const SAMPLE_OFFERS: SampleOfferPreset[] = [
  {
    id: 'indira',
    label: 'Example 1: Indira Infotech (6.5 LPA CTC, 2-yr bond)',
    text: 'Dear Karan, we are pleased to offer you the role of Associate Software Engineer at Indira Infotech. Your annual CTC will be Rs 6.5 lakhs, including variable pay of 10% linked to company performance. A joining bonus of Rs 25,000 is payable after 6 months. Notice period is 60 days. A service agreement of 2 years applies; leaving earlier means a penalty of Rs 1 lakh.',
  },
  {
    id: 'cubbon',
    label: 'Example 2: Cubbon Analytics (4.2 LPA fixed)',
    text: 'Offer: Trainee Analyst, Cubbon Analytics. CTC 4.2 LPA fixed. Training period 3 months with stipend Rs 12,000. Notice period 30 days.',
  },
  {
    id: 'namma',
    label: 'Example 3: Namma Fintech (12 LPA, 20% variable)',
    text: 'Congratulations! You are selected as Data Engineer at Namma Fintech. Total CTC Rs 12 lakhs including 20% variable. Relocation bonus Rs 50,000, recoverable if you leave within 12 months. Notice period 90 days.',
  },
];

export const TESTS: TestCase[] = [
  {
    question: 'Break up a 6 lakh CTC with 40 percent basic',
    wantTools: ['ctc_breakup'],
    wantInputs: { ctc_lakhs: 6, basic_percent: 40 },
  },
  {
    question: 'What is the in-hand for 12 LPA if basic is 50 percent?',
    wantTools: ['ctc_breakup'],
    wantInputs: { ctc_lakhs: 12, basic_percent: 50 },
  },
  {
    question: 'My CTC is 8 lakhs and 15 percent is variable. How much is guaranteed?',
    wantTools: ['variable_impact'],
    wantInputs: { ctc_lakhs: 8, variable_percent: 15 },
  },
  {
    question: 'How much variable pay is there in 10 LPA with 20 percent variable?',
    wantTools: ['variable_impact'],
    wantInputs: { ctc_lakhs: 10, variable_percent: 20 },
  },
  {
    question: 'Compare offer A 6.5 lakhs with 10 percent variable and offer B 6 lakhs with 0 percent variable',
    wantTools: ['compare_offers'],
    wantInputs: { ctc_a_lakhs: 6.5, variable_a_percent: 10, ctc_b_lakhs: 6, variable_b_percent: 0 },
  },
  {
    question: 'Offer A is 12 LPA with 20 percent variable, offer B is 10 LPA fixed. Which is better?',
    wantTools: ['compare_offers'],
    wantInputs: { ctc_a_lakhs: 12, variable_a_percent: 20, ctc_b_lakhs: 10, variable_b_percent: 0 },
  },
  {
    question: 'tell me a joke',
    wantTools: [],
    wantInputs: {},
  },
  {
    question: 'what is the capital of Karnataka?',
    wantTools: [],
    wantInputs: {},
  },
];
