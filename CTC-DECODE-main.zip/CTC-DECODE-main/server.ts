import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI, ThinkingLevel, Type, type Content, type FunctionDeclaration } from '@google/genai';
import {
  ctcBreakup,
  variableImpact,
  compareOffers,
  numberFrom,
  RULES,
  SYSTEM_OFFER,
  SYSTEM_EXPLAIN,
  type AgentStep,
} from './src/lib/ctcEngine.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const MODEL = 'gemini-4-hydrogen';

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in environment secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const toolDeclarations: FunctionDeclaration[] = [
  {
    name: 'ctc_breakup',
    description:
      'Break a yearly CTC (in lakhs) into monthly basic, HRA, special allowance, employer PF and gratuity, and estimate the monthly amount before income tax. Demo formula, check with HR.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        ctc_lakhs: {
          type: Type.NUMBER,
          description: 'Annual CTC in lakhs (e.g., 6 for 6 LPA, 12 for 12 LPA).',
        },
        basic_percent: {
          type: Type.NUMBER,
          description: 'Percentage of CTC allocated to Basic salary (typically 40 or 50).',
        },
      },
      required: ['ctc_lakhs', 'basic_percent'],
    },
  },
  {
    name: 'variable_impact',
    description:
      'Show how much of the CTC is variable pay that is NOT guaranteed, and the guaranteed yearly and monthly amount.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        ctc_lakhs: {
          type: Type.NUMBER,
          description: 'Annual CTC in lakhs.',
        },
        variable_percent: {
          type: Type.NUMBER,
          description: 'Share of CTC that is variable pay (0-100).',
        },
      },
      required: ['ctc_lakhs', 'variable_percent'],
    },
  },
  {
    name: 'compare_offers',
    description:
      'Compare two job offers on guaranteed yearly pay (CTC minus the variable part) and say which is higher.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        ctc_a_lakhs: { type: Type.NUMBER, description: 'Offer A annual CTC in lakhs.' },
        variable_a_percent: { type: Type.NUMBER, description: 'Offer A variable pay percentage (0 if fixed).' },
        ctc_b_lakhs: { type: Type.NUMBER, description: 'Offer B annual CTC in lakhs.' },
        variable_b_percent: { type: Type.NUMBER, description: 'Offer B variable pay percentage (0 if fixed).' },
      },
      required: ['ctc_a_lakhs', 'variable_a_percent', 'ctc_b_lakhs', 'variable_b_percent'],
    },
  },
];

function executeTool(
  name: string,
  rawArgs: Record<string, unknown>,
): {
  inputs: Record<string, number>;
  result: ReturnType<typeof ctcBreakup> | ReturnType<typeof variableImpact> | ReturnType<typeof compareOffers>;
} {
  const args: Record<string, number> = {};
  for (const [k, v] of Object.entries(rawArgs || {})) {
    args[k] = numberFrom(v, 0);
  }

  if (name === 'ctc_breakup') {
    const inputs: Record<string, number> = {
      ctc_lakhs: args.ctc_lakhs ?? 0,
      basic_percent: args.basic_percent ?? 40,
    };
    return {
      inputs,
      result: ctcBreakup(inputs.ctc_lakhs, inputs.basic_percent),
    };
  }
  if (name === 'variable_impact') {
    const inputs: Record<string, number> = {
      ctc_lakhs: args.ctc_lakhs ?? 0,
      variable_percent: args.variable_percent ?? 0,
    };
    return {
      inputs,
      result: variableImpact(inputs.ctc_lakhs, inputs.variable_percent),
    };
  }
  if (name === 'compare_offers') {
    const inputs: Record<string, number> = {
      ctc_a_lakhs: args.ctc_a_lakhs ?? 0,
      variable_a_percent: args.variable_a_percent ?? 0,
      ctc_b_lakhs: args.ctc_b_lakhs ?? 0,
      variable_b_percent: args.variable_b_percent ?? 0,
    };
    return {
      inputs,
      result: compareOffers(
        inputs.ctc_a_lakhs,
        inputs.variable_a_percent,
        inputs.ctc_b_lakhs,
        inputs.variable_b_percent,
      ),
    };
  }
  return {
    inputs: args,
    result: { error: `Unknown tool: ${name}` },
  };
}

interface ChatHistoryMessage {
  role: 'user' | 'assistant';
  content: string;
}

async function runAgentLoop(message: string, history: ChatHistoryMessage[] = []) {
  const ai = getAiClient();
  const contents: Content[] = [];

  for (const m of history.slice(-6)) {
    contents.push({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    });
  }
  contents.push({
    role: 'user',
    parts: [{ text: message }],
  });

  const steps: AgentStep[] = [];
  const seenCalls = new Set<string>();
  let finalAnswer = '';

  for (let round = 0; round < 4; round++) {
    const response = await ai.models.generateContent({
      model: MODEL,
      contents,
      config: {
        systemInstruction: RULES,
        tools: [{ functionDeclarations: toolDeclarations }],
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      },
    });

    const functionCalls = response.functionCalls;
    const candidateContent = response.candidates?.[0]?.content;

    if (!functionCalls || functionCalls.length === 0) {
      finalAnswer = (response.text || '').trim();
      break;
    }

    if (candidateContent) {
      contents.push(candidateContent);
    }

    const responseParts = [];
    let anyNewCall = false;

    for (const fc of functionCalls) {
      const toolName = fc.name || '';
      const rawArgs = (fc.args || {}) as Record<string, unknown>;
      const signature = `${toolName}:${JSON.stringify(rawArgs)}`;
      if (seenCalls.has(signature)) {
        continue;
      }
      seenCalls.add(signature);
      anyNewCall = true;

      const executed = executeTool(toolName, rawArgs);
      if (toolName === 'ctc_breakup' || toolName === 'variable_impact' || toolName === 'compare_offers') {
        steps.push({
          tool: toolName,
          inputs: executed.inputs,
          result: executed.result,
        });
      }

      responseParts.push({
        functionResponse: {
          id: fc.id,
          name: toolName,
          response: { result: executed.result },
        },
      });
    }

    if (!anyNewCall) {
      break;
    }

    contents.push({
      role: 'user',
      parts: responseParts,
    });
  }

  if (!finalAnswer) {
    finalAnswer = 'I checked the numbers using the calculator tools above. Remember to confirm the exact salary breakup with HR.';
  }

  return { answer: finalAnswer, steps };
}

function formatApiError(err: unknown): { status: number; message: string } {
  const msg = err instanceof Error ? err.message : String(err);
  if (msg.includes('GEMINI_API_KEY')) {
    return { status: 503, message: 'Server Gemini API key is not configured.' };
  }
  if (msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED')) {
    return { status: 429, message: 'AI quota temporarily busy. Please try again in a moment.' };
  }
  return { status: 500, message: msg || 'AI service request failed.' };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      model: MODEL,
      configured: Boolean(process.env.GEMINI_API_KEY),
    });
  });

  app.post('/api/extract-offer', async (req, res) => {
    try {
      const offerText = String(req.body?.offerText || '').trim();
      if (!offerText) {
        res.status(400).json({ error: 'Offer letter text is required.' });
        return;
      }

      const ai = getAiClient();
      const userPrompt = `Offer letter:\n${offerText}`;
      const response = await ai.models.generateContent({
        model: MODEL,
        contents: userPrompt,
        config: {
          systemInstruction: SYSTEM_OFFER,
          responseMimeType: 'application/json',
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          seed: 7,
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              company: { type: Type.STRING, description: 'Company name from the offer letter.' },
              ctc_lakhs: { type: Type.NUMBER, description: 'Yearly CTC in lakhs (e.g. 6.5).' },
              variable_percent: { type: Type.NUMBER, description: 'Variable pay percentage (0 if fixed).' },
              joining_bonus: { type: Type.NUMBER, description: 'Joining or relocation bonus in INR (0 if none).' },
              notice_period_days: { type: Type.INTEGER, description: 'Notice period in days (0 if not mentioned).' },
              red_flags: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Only literal restrictive clauses like bonds, penalties, deposits, clawbacks.',
              },
            },
            required: ['company', 'ctc_lakhs', 'variable_percent', 'joining_bonus', 'notice_period_days', 'red_flags'],
          },
        },
      });

      const parsed = JSON.parse((response.text || '{}').trim());
      res.json({
        extracted: {
          company: String(parsed.company || 'Company'),
          ctc_lakhs: numberFrom(parsed.ctc_lakhs, 0),
          variable_percent: numberFrom(parsed.variable_percent, 0),
          joining_bonus: numberFrom(parsed.joining_bonus, 0),
          notice_period_days: Math.round(numberFrom(parsed.notice_period_days, 0)),
          red_flags: Array.isArray(parsed.red_flags) ? parsed.red_flags.map(String).filter(Boolean) : [],
        },
        debug: {
          system: SYSTEM_OFFER,
          user: userPrompt,
        },
      });
    } catch (err) {
      const formatted = formatApiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/explain-offer', async (req, res) => {
    try {
      const { meta, breakup, impact } = req.body || {};
      if (!meta || !breakup || !impact) {
        res.status(400).json({ error: 'Calculated offer metrics are required.' });
        return;
      }

      const ai = getAiClient();
      const userPrompt =
        `Extracted Offer Fields:\n${JSON.stringify(meta)}\n\n` +
        `CTC Breakup Results:\n${JSON.stringify(breakup)}\n\n` +
        `Variable Pay Impact:\n${JSON.stringify(impact)}`;

      const response = await ai.models.generateContent({
        model: MODEL,
        contents: userPrompt,
        config: {
          systemInstruction: SYSTEM_EXPLAIN,
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        },
      });

      res.json({
        explanation: (response.text || '').trim(),
        debug: {
          system: SYSTEM_EXPLAIN,
          user: userPrompt,
        },
      });
    } catch (err) {
      const formatted = formatApiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/agent-chat', async (req, res) => {
    try {
      const message = String(req.body?.message || '').trim();
      const history = Array.isArray(req.body?.history) ? (req.body.history as ChatHistoryMessage[]) : [];
      if (!message) {
        res.status(400).json({ error: 'Message is required.' });
        return;
      }

      const result = await runAgentLoop(message, history);
      res.json(result);
    } catch (err) {
      const formatted = formatApiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/run-test-case', async (req, res) => {
    try {
      const question = String(req.body?.question || '').trim();
      const wantTools = Array.isArray(req.body?.wantTools) ? (req.body.wantTools as string[]) : [];
      const wantInputs = (req.body?.wantInputs || {}) as Record<string, unknown>;

      if (!question) {
        res.status(400).json({ error: 'Test question is required.' });
        return;
      }

      const { steps } = await runAgentLoop(question, []);
      const usedTools = Array.from(new Set(steps.map((s) => s.tool))).sort();
      const expectedTools = [...wantTools].sort();

      if (JSON.stringify(usedTools) !== JSON.stringify(expectedTools)) {
        res.json({
          passed: false,
          reason: `used [${usedTools.join(', ')}], wanted [${expectedTools.join(', ')}]`,
          usedTools,
          steps,
        });
        return;
      }

      for (const step of steps) {
        for (const [key, wantVal] of Object.entries(wantInputs)) {
          if (key in step.inputs) {
            const gotVal = step.inputs[key];
            if (typeof wantVal === 'number') {
              if (Math.abs(numberFrom(gotVal) - wantVal) >= 0.01) {
                res.json({
                  passed: false,
                  reason: `${key} was ${gotVal}, wanted ${wantVal}`,
                  usedTools,
                  steps,
                });
                return;
              }
            }
          }
        }
      }

      res.json({
        passed: true,
        reason: 'Passed',
        usedTools,
        steps,
      });
    } catch (err) {
      const formatted = formatApiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  if (process.env.NODE_ENV === 'production') {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CTC Decoder server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
